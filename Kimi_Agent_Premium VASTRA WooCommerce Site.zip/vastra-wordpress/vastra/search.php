<?php
/**
 * Search results template.
 *
 * @package VASTRA
 */

get_header();
?>
<main id="primary" class="site-main container content-area">
	<header class="page-header">
		<h1 class="entry-title">
			<?php
			/* translators: %s: search query. */
			printf( esc_html__( 'Search results for: %s', 'vastra' ), '<span>' . esc_html( get_search_query() ) . '</span>' );
			?>
		</h1>
	</header>
	<?php if ( have_posts() ) : ?>
		<div class="post-grid">
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry-card' ); ?>>
					<div class="entry-card-body">
						<h2 class="entry-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20 ) ); ?></p>
						<a class="text-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'View', 'vastra' ); ?></a>
					</div>
				</article>
				<?php
			endwhile;
			?>
		</div>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<p><?php esc_html_e( 'No results. Try a different search, or browse the shop.', 'vastra' ); ?></p>
	<?php endif; ?>
</main>
<?php
get_footer();
