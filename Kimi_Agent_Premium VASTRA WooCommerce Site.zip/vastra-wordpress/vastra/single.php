<?php
/**
 * Single post template.
 *
 * @package VASTRA
 */

get_header();
?>
<main id="primary" class="site-main container content-area">
	<?php
	while ( have_posts() ) :
		the_post();
		?>
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry' ); ?>>
			<header class="entry-header">
				<h1 class="entry-title"><?php the_title(); ?></h1>
				<p class="entry-meta"><?php echo esc_html( get_the_date() ); ?></p>
			</header>
			<?php if ( has_post_thumbnail() ) : ?>
				<div class="entry-media"><?php the_post_thumbnail( 'large' ); ?></div>
			<?php endif; ?>
			<div class="entry-content"><?php the_content(); ?></div>
		</article>
		<?php
		if ( comments_open() || get_comments_number() ) {
			comments_template();
		}
	endwhile;
	?>
</main>
<?php
get_footer();
