<?php
/**
 * Site header.
 *
 * @package VASTRA
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#primary"><?php esc_html_e( 'Skip to content', 'vastra' ); ?></a>

<header class="site-header" id="site-header">
	<div class="topbar">
		<div class="container topbar-inner">
			<span class="topbar-note"><?php esc_html_e( 'Island-wide delivery across Sri Lanka', 'vastra' ); ?></span>
			<div class="topbar-contact">
				<a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', get_theme_mod( 'vastra_phone', '+94 XX XXX XXXX' ) ) ); ?>">
					<?php echo vastra_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<span><?php echo esc_html( get_theme_mod( 'vastra_phone', '+94 XX XXX XXXX' ) ); ?></span>
				</a>
			</div>
		</div>
	</div>

	<div class="container header-inner">
		<div class="site-branding">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<a class="site-logo-text" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
					VASTRA<span class="logo-dot">.</span>
				</a>
			<?php endif; ?>
		</div>

		<nav class="primary-nav" id="primary-nav" aria-label="<?php esc_attr_e( 'Primary', 'vastra' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_class'     => 'primary-menu',
					'fallback_cb'    => 'vastra_primary_menu_fallback',
					'depth'          => 2,
				)
			);
			?>
		</nav>

		<div class="header-actions">
			<?php if ( class_exists( 'WooCommerce' ) ) : ?>
				<?php vastra_header_cart(); ?>
			<?php endif; ?>
			<button class="nav-toggle" id="nav-toggle" aria-expanded="false" aria-controls="primary-nav" aria-label="<?php esc_attr_e( 'Open menu', 'vastra' ); ?>">
				<span class="icon-menu"><?php echo vastra_icon( 'menu' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<span class="icon-close"><?php echo vastra_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			</button>
		</div>
	</div>
</header>

<?php
/**
 * Fallback menu when no menu is assigned yet.
 */
function vastra_primary_menu_fallback() {
	$items = array(
		__( 'Home', 'vastra' )          => home_url( '/' ),
		__( 'Shop', 'vastra' )          => function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' ),
		__( 'Custom Orders', 'vastra' ) => home_url( '/custom-orders/' ),
	);
	echo '<ul class="primary-menu">';
	foreach ( $items as $label => $url ) {
		echo '<li><a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a></li>';
	}
	echo '</ul>';
}
