<?php
/**
 * 404 template.
 *
 * @package VASTRA
 */

get_header();
?>
<main id="primary" class="site-main container content-area not-found">
	<h1 class="entry-title"><?php esc_html_e( 'Page not found', 'vastra' ); ?></h1>
	<p><?php esc_html_e( 'The page you are looking for has moved or no longer exists.', 'vastra' ); ?></p>
	<div class="hero-actions">
		<a class="btn btn--gold" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to Home', 'vastra' ); ?></a>
		<?php if ( class_exists( 'WooCommerce' ) ) : ?>
			<a class="btn btn--outline" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"><?php esc_html_e( 'Browse Costumes', 'vastra' ); ?></a>
		<?php endif; ?>
	</div>
	<?php get_search_form(); ?>
</main>
<?php
get_footer();
