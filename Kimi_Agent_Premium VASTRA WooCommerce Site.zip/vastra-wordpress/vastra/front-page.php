<?php
/**
 * Homepage template.
 *
 * @package VASTRA
 */

get_header();

$hero_image_id = (int) get_theme_mod( 'vastra_hero_image' );
$hero_url      = $hero_image_id ? wp_get_attachment_image_url( $hero_image_id, 'vastra-hero' ) : '';
$shop_url      = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );
$wa_hero       = vastra_whatsapp_link( __( 'Hello VASTRA! I would like to place an order.', 'vastra' ) );
?>

<main id="primary" class="site-main">

	<!-- Hero -->
	<section class="hero <?php echo $hero_url ? 'hero--has-image' : 'hero--pattern'; ?>">
		<?php if ( $hero_url ) : ?>
			<div class="hero-media">
				<?php echo wp_get_attachment_image( $hero_image_id, 'vastra-hero', false, array( 'fetchpriority' => 'high', 'decoding' => 'async' ) ); ?>
			</div>
		<?php endif; ?>
		<div class="hero-overlay"></div>
		<div class="container hero-content">
			<p class="hero-kicker"><?php esc_html_e( 'Sri Lankan Dance Costumes · Est. in Sri Lanka', 'vastra' ); ?></p>
			<h1 class="hero-title"><?php echo esc_html( get_theme_mod( 'vastra_hero_title', __( 'Celebrate Every Performance with VASTRA', 'vastra' ) ) ); ?></h1>
			<p class="hero-subtitle"><?php echo esc_html( get_theme_mod( 'vastra_hero_subtitle', __( 'Handcrafted Kandyan, Low Country, Sabaragamuwa and Bharatanatyam costumes — tailored in Sri Lanka, delivered island-wide.', 'vastra' ) ) ); ?></p>
			<div class="hero-actions">
				<a class="btn btn--gold" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Shop Collection', 'vastra' ); ?></a>
				<?php if ( $wa_hero ) : ?>
					<a class="btn btn--whatsapp" href="<?php echo esc_url( $wa_hero ); ?>" target="_blank" rel="noopener noreferrer">
						<?php echo vastra_icon( 'whatsapp' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php esc_html_e( 'Order on WhatsApp', 'vastra' ); ?>
					</a>
				<?php endif; ?>
			</div>
		</div>
	</section>

	<!-- Featured categories -->
	<section class="section" id="categories">
		<div class="container">
			<header class="section-head">
				<h2 class="section-title"><?php esc_html_e( 'Shop by Tradition', 'vastra' ); ?></h2>
				<p class="section-sub"><?php esc_html_e( 'From sacred up-country regalia to vibrant low-country masks — find the costume your performance deserves.', 'vastra' ); ?></p>
			</header>
			<?php
			if ( class_exists( 'WooCommerce' ) ) {
				$featured_slugs = array( 'kandyan', 'low-country', 'sabaragamuwa', 'bharatanatyam', 'school-kids', 'stage-wear', 'accessories', 'custom-made' );
				$terms          = get_terms(
					array(
						'taxonomy'   => 'product_cat',
						'hide_empty' => false,
						'slug'       => $featured_slugs,
					)
				);
				if ( is_wp_error( $terms ) || ! $terms ) {
					$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => true, 'number' => 8 ) );
				}
				if ( ! is_wp_error( $terms ) && $terms ) {
					echo '<div class="category-grid">';
					foreach ( $terms as $term ) {
						$thumb_id  = get_term_meta( $term->term_id, 'thumbnail_id', true );
						$image     = $thumb_id ? wp_get_attachment_image( $thumb_id, 'vastra-card', false, array( 'loading' => 'lazy', 'decoding' => 'async' ) ) : '';
						$fallbacks = array(
							'kandyan'        => 'kandyan-1.jpg',
							'low-country'    => 'lowcountry-1.jpg',
							'sabaragamuwa'   => 'sabaragamuwa-1.jpg',
							'bharatanatyam'  => 'bharatanatyam-1.jpg',
							'school-kids'    => 'kids-1.jpg',
							'stage-wear'     => 'stagewear-1.jpg',
							'accessories'    => 'accessories-1.jpg',
							'custom-made'    => 'custom-1.jpg',
						);
						if ( ! $image && isset( $fallbacks[ $term->slug ] ) && defined( 'VASTRA_CORE_URL' ) ) {
							$image = '<img src="' . esc_url( VASTRA_CORE_URL . 'assets/images/' . $fallbacks[ $term->slug ] ) . '" alt="' . esc_attr( $term->name ) . '" loading="lazy" decoding="async">';
						}
						echo '<a class="category-card" href="' . esc_url( get_term_link( $term ) ) . '">';
						echo '<span class="category-card-media">' . $image . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						echo '<span class="category-card-label">' . esc_html( $term->name ) . '</span>';
						echo '</a>';
					}
					echo '</div>';
				}
			}
			?>
		</div>
	</section>

	<?php if ( class_exists( 'WooCommerce' ) ) : ?>

		<!-- Best sellers -->
		<section class="section section--ivory">
			<div class="container">
				<header class="section-head">
					<h2 class="section-title"><?php esc_html_e( 'Best Sellers', 'vastra' ); ?></h2>
					<p class="section-sub"><?php esc_html_e( 'The costumes dancers across Sri Lanka reach for again and again.', 'vastra' ); ?></p>
				</header>
				<?php echo do_shortcode( '[products limit="4" columns="4" best_selling="true" visibility="visible"]' ); ?>
				<div class="section-cta">
					<a class="btn btn--outline" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'View All Costumes', 'vastra' ); ?> <?php echo vastra_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
				</div>
			</div>
		</section>

		<!-- New arrivals -->
		<section class="section">
			<div class="container">
				<header class="section-head">
					<h2 class="section-title"><?php esc_html_e( 'New Arrivals', 'vastra' ); ?></h2>
					<p class="section-sub"><?php esc_html_e( 'Fresh from the atelier — the latest additions to the VASTRA collection.', 'vastra' ); ?></p>
				</header>
				<?php echo do_shortcode( '[products limit="4" columns="4" orderby="date" order="DESC" visibility="visible"]' ); ?>
			</div>
		</section>

	<?php endif; ?>

	<!-- Custom orders -->
	<section class="section custom-band">
		<div class="container custom-band-inner">
			<div class="custom-band-copy">
				<p class="hero-kicker"><?php esc_html_e( 'Made to Measure', 'vastra' ); ?></p>
				<h2 class="section-title"><?php esc_html_e( 'Custom-Made Costumes', 'vastra' ); ?></h2>
				<p><?php esc_html_e( 'Send us your measurements, colours, reference images and performance date — our artisans will craft a costume that fits you and your choreography perfectly.', 'vastra' ); ?></p>
				<div class="hero-actions">
					<a class="btn btn--gold" href="<?php echo esc_url( home_url( '/custom-orders/' ) ); ?>"><?php esc_html_e( 'Start a Custom Order', 'vastra' ); ?></a>
				</div>
			</div>
			<div class="custom-band-points">
				<div class="point">
					<?php echo vastra_icon( 'ruler' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<h3><?php esc_html_e( 'Exact Measurements', 'vastra' ); ?></h3>
					<p><?php esc_html_e( 'Guided measurement form for a perfect fit.', 'vastra' ); ?></p>
				</div>
				<div class="point">
					<?php echo vastra_icon( 'shield' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<h3><?php esc_html_e( 'Craft Guarantee', 'vastra' ); ?></h3>
					<p><?php esc_html_e( 'Quality-checked stitching, beadwork and finish.', 'vastra' ); ?></p>
				</div>
				<div class="point">
					<?php echo vastra_icon( 'truck' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<h3><?php esc_html_e( 'On-Time Delivery', 'vastra' ); ?></h3>
					<p><?php esc_html_e( 'Scheduled around your performance date.', 'vastra' ); ?></p>
				</div>
			</div>
		</div>
	</section>

	<!-- Genuine reviews (real WooCommerce reviews only — no fabricated content) -->
	<section class="section section--ivory">
		<div class="container">
			<header class="section-head">
				<h2 class="section-title"><?php esc_html_e( 'What Dancers Say', 'vastra' ); ?></h2>
			</header>
			<?php
			$reviews = function_exists( 'vastra_get_genuine_reviews' ) ? vastra_get_genuine_reviews( 6 ) : array();
			if ( $reviews ) :
				echo '<div class="review-grid">';
				foreach ( $reviews as $review ) :
					$rating = get_comment_meta( $review->comment_ID, 'rating', true );
					?>
					<figure class="review-card">
						<?php if ( $rating ) : ?>
							<div class="review-stars" aria-label="<?php echo esc_attr( sprintf( __( 'Rated %s out of 5', 'vastra' ), $rating ) ); ?>">
								<?php echo str_repeat( '<span class="star filled">★</span>', (int) $rating ) . str_repeat( '<span class="star">★</span>', 5 - (int) $rating ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							</div>
						<?php endif; ?>
						<blockquote><?php echo esc_html( wp_trim_words( $review->comment_content, 40 ) ); ?></blockquote>
						<figcaption>— <?php echo esc_html( $review->comment_author ); ?></figcaption>
					</figure>
					<?php
				endforeach;
				echo '</div>';
			else :
				?>
				<p class="review-empty"><?php esc_html_e( 'Customer reviews will appear here once your first verified buyers share their experience. VASTRA only publishes genuine reviews.', 'vastra' ); ?></p>
			<?php endif; ?>
		</div>
	</section>

	<!-- Delivery information -->
	<section class="section delivery-band" id="delivery">
		<div class="container delivery-inner">
			<div class="delivery-icon"><?php echo vastra_icon( 'truck' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
			<div>
				<h2 class="section-title"><?php esc_html_e( 'Island-wide Delivery', 'vastra' ); ?></h2>
				<p><?php echo esc_html( get_theme_mod( 'vastra_delivery_text', __( 'Island-wide delivery across Sri Lanka. Dispatch within 2–4 working days for ready-made costumes; custom orders are scheduled after measurement confirmation. Delivery fees are calculated at checkout by district.', 'vastra' ) ) ); ?></p>
				<a class="text-link" href="<?php echo esc_url( home_url( '/shipping-delivery/' ) ); ?>"><?php esc_html_e( 'Read shipping &amp; delivery details', 'vastra' ); ?> <?php echo vastra_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
			</div>
		</div>
	</section>

	<!-- Social -->
	<?php $social = vastra_social_links(); ?>
	<?php if ( $social ) : ?>
		<section class="section social-band">
			<div class="container social-band-inner">
				<h2 class="section-title"><?php esc_html_e( 'Follow the Movement', 'vastra' ); ?></h2>
				<div class="social-links social-links--large">
					<?php foreach ( $social as $network => $url ) : ?>
						<a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( ucfirst( $network ) ); ?>">
							<?php echo vastra_icon( $network ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</a>
					<?php endforeach; ?>
				</div>
			</div>
		</section>
	<?php endif; ?>

</main>

<?php
get_footer();
