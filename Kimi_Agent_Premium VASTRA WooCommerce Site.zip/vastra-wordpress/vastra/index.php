<?php
/**
 * Fallback index template.
 *
 * @package VASTRA
 */

get_header();
?>
<main id="primary" class="site-main container content-area">
	<?php if ( have_posts() ) : ?>
		<?php if ( is_home() && ! is_front_page() ) : ?>
			<header class="page-header"><h1 class="entry-title"><?php single_post_title(); ?></h1></header>
		<?php endif; ?>
		<div class="post-grid">
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry-card' ); ?>>
					<?php if ( has_post_thumbnail() ) : ?>
						<a class="entry-card-media" href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'vastra-card', array( 'loading' => 'lazy' ) ); ?></a>
					<?php endif; ?>
					<div class="entry-card-body">
						<h2 class="entry-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<p><?php echo esc_html( get_the_excerpt() ); ?></p>
						<a class="text-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read more', 'vastra' ); ?></a>
					</div>
				</article>
				<?php
			endwhile;
			?>
		</div>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<p><?php esc_html_e( 'Nothing found.', 'vastra' ); ?></p>
	<?php endif; ?>
</main>
<?php
get_footer();
