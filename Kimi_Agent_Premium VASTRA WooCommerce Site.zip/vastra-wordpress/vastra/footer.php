<?php
/**
 * Site footer.
 *
 * @package VASTRA
 */
?>
<footer class="site-footer">
	<div class="container footer-grid">
		<div class="footer-col footer-brand">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<a class="site-logo-text" href="<?php echo esc_url( home_url( '/' ) ); ?>">VASTRA<span class="logo-dot">.</span></a>
			<?php endif; ?>
			<p><?php esc_html_e( 'Premium Sri Lankan dance costumes — handcrafted with tradition, tailored for every stage.', 'vastra' ); ?></p>
			<?php
			$social = vastra_social_links();
			if ( $social ) :
				?>
				<div class="social-links">
					<?php foreach ( $social as $network => $url ) : ?>
						<a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( ucfirst( $network ) ); ?>">
							<?php echo vastra_icon( $network ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</a>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>

		<div class="footer-col">
			<h3><?php esc_html_e( 'Explore', 'vastra' ); ?></h3>
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'footer',
					'container'      => false,
					'menu_class'     => 'footer-menu',
					'fallback_cb'    => false,
					'depth'          => 1,
				)
			);
			?>
		</div>

		<div class="footer-col">
			<h3><?php esc_html_e( 'Collections', 'vastra' ); ?></h3>
			<?php
			if ( class_exists( 'WooCommerce' ) ) {
				$cats = get_terms(
					array(
						'taxonomy'   => 'product_cat',
						'hide_empty' => true,
						'number'     => 8,
					)
				);
				if ( ! is_wp_error( $cats ) && $cats ) {
					echo '<ul class="footer-menu">';
					foreach ( $cats as $cat ) {
						echo '<li><a href="' . esc_url( get_term_link( $cat ) ) . '">' . esc_html( $cat->name ) . '</a></li>';
					}
					echo '</ul>';
				}
			}
			?>
		</div>

		<div class="footer-col footer-contact">
			<h3><?php esc_html_e( 'Contact', 'vastra' ); ?></h3>
			<p><?php echo esc_html( get_theme_mod( 'vastra_address', __( 'Your studio address, City, Sri Lanka', 'vastra' ) ) ); ?></p>
			<p><a href="mailto:<?php echo esc_attr( get_theme_mod( 'vastra_email', 'hello@example.com' ) ); ?>"><?php echo esc_html( get_theme_mod( 'vastra_email', 'hello@example.com' ) ); ?></a></p>
			<p><a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', get_theme_mod( 'vastra_phone', '' ) ) ); ?>"><?php echo esc_html( get_theme_mod( 'vastra_phone', '+94 XX XXX XXXX' ) ); ?></a></p>
			<?php
			$wa = vastra_whatsapp_link( __( 'Hello VASTRA! I have a question about a costume.', 'vastra' ) );
			if ( $wa ) :
				?>
				<p><a class="footer-whatsapp" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener noreferrer"><?php echo vastra_icon( 'whatsapp' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <?php esc_html_e( 'Chat on WhatsApp', 'vastra' ); ?></a></p>
			<?php endif; ?>
		</div>
	</div>

	<div class="footer-bottom">
		<div class="container footer-bottom-inner">
			<p>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All rights reserved.', 'vastra' ); ?></p>
			<p class="footer-payments"><?php esc_html_e( 'Cash on Delivery &amp; Bank Transfer accepted (Sri Lanka only)', 'vastra' ); ?></p>
		</div>
	</div>
</footer>

<?php
// Floating WhatsApp button (toggle + number live in VASTRA Core settings).
if ( get_option( 'vastra_floating_whatsapp', '1' ) === '1' ) {
	$wa_float = vastra_whatsapp_link( __( 'Hello VASTRA!', 'vastra' ) );
	if ( $wa_float ) :
		?>
		<a class="vastra-float-wa" href="<?php echo esc_url( $wa_float ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'Chat with VASTRA on WhatsApp', 'vastra' ); ?>">
			<?php echo vastra_icon( 'whatsapp' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</a>
		<?php
	endif;
}
?>

<?php wp_footer(); ?>
</body>
</html>
