<?php
/**
 * WooCommerce integration for VASTRA.
 *
 * @package VASTRA
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WooCommerce' ) ) {
	return;
}

/**
 * Replace WooCommerce's default wrappers with theme containers.
 */
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );

add_action(
	'woocommerce_before_main_content',
	function () {
		echo '<main id="primary" class="site-main container">';
	},
	10
);
add_action(
	'woocommerce_after_main_content',
	function () {
		echo '</main>';
	},
	10
);

// Clean shop layout: theme CSS handles breadcrumbs/notices styling.
add_filter( 'woocommerce_show_page_title', '__return_true' );

/**
 * Products per row / per page.
 */
add_filter(
	'loop_shop_columns',
	function () {
		return 3;
	}
);
add_filter(
	'loop_shop_per_page',
	function () {
		return 12;
	}
);

/**
 * Header cart link with live count (WooCommerce fragments keep it fresh).
 */
function vastra_header_cart() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	$count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
	?>
	<a class="vastra-cart-link" href="<?php echo esc_url( wc_get_cart_url() ); ?>" aria-label="<?php esc_attr_e( 'View cart', 'vastra' ); ?>">
		<?php echo vastra_icon( 'cart' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<span class="vastra-cart-count"><?php echo esc_html( $count ); ?></span>
	</a>
	<?php
}

/**
 * Refresh cart count via AJAX fragments.
 */
function vastra_cart_fragment( $fragments ) {
	ob_start();
	vastra_header_cart();
	$fragments['a.vastra-cart-link'] = ob_get_clean();
	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'vastra_cart_fragment' );

/**
 * Mark best sellers / new arrivals with a badge on product loops.
 */
function vastra_product_badges() {
	global $product;
	if ( ! $product ) {
		return;
	}
	if ( has_term( 'best-seller', 'product_tag', $product->get_id() ) ) {
		echo '<span class="vastra-badge vastra-badge--best">' . esc_html__( 'Best Seller', 'vastra' ) . '</span>';
	}
	$created = strtotime( $product->get_date_created() );
	if ( $created && $created > strtotime( '-30 days' ) ) {
		echo '<span class="vastra-badge vastra-badge--new">' . esc_html__( 'New', 'vastra' ) . '</span>';
	}
}
add_action( 'woocommerce_before_shop_loop_item_title', 'vastra_product_badges', 5 );

/**
 * Reviews section helper: fetch genuine, approved WooCommerce reviews only.
 * Never fabricate reviews — returns an empty array when none exist.
 */
function vastra_get_genuine_reviews( $limit = 6 ) {
	return get_comments(
		array(
			'type'   => 'review',
			'status' => 'approve',
			'number' => $limit,
		)
	);
}
