<?php
/**
 * VASTRA Customizer: brand settings, hero, contact placeholders, social links.
 *
 * @package VASTRA
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register Customizer settings.
 *
 * @param WP_Customize_Manager $wp_customize Customizer instance.
 */
function vastra_customize_register( $wp_customize ) {

	$wp_customize->add_panel(
		'vastra_store',
		array(
			'title'       => __( 'VASTRA Store', 'vastra' ),
			'description' => __( 'Brand, hero, contact and social settings. Replace every placeholder with your real details before launch.', 'vastra' ),
			'priority'    => 30,
		)
	);

	// ── Contact ────────────────────────────────────────────────────────────
	$wp_customize->add_section(
		'vastra_contact',
		array(
			'title' => __( 'Contact & WhatsApp', 'vastra' ),
			'panel' => 'vastra_store',
		)
	);

	$wp_customize->add_setting(
		'vastra_whatsapp_number',
		array(
			'default'           => '',
			'sanitize_callback' => 'vastra_sanitize_phone',
		)
	);
	$wp_customize->add_control(
		'vastra_whatsapp_number',
		array(
			'section'     => 'vastra_contact',
			'label'       => __( 'Store WhatsApp number', 'vastra' ),
			'description' => __( 'International format, digits only — e.g. 9477XXXXXXX. Used by the Order on WhatsApp buttons. PLACEHOLDER until you set your real number.', 'vastra' ),
			'type'        => 'text',
		)
	);

	$wp_customize->add_setting(
		'vastra_phone',
		array(
			'default'           => '+94 XX XXX XXXX',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'vastra_phone',
		array(
			'section'     => 'vastra_contact',
			'label'       => __( 'Display phone number (placeholder)', 'vastra' ),
			'type'        => 'text',
		)
	);

	$wp_customize->add_setting(
		'vastra_email',
		array(
			'default'           => 'hello@example.com',
			'sanitize_callback' => 'sanitize_email',
		)
	);
	$wp_customize->add_control(
		'vastra_email',
		array(
			'section'     => 'vastra_contact',
			'label'       => __( 'Contact email (placeholder)', 'vastra' ),
			'type'        => 'email',
		)
	);

	$wp_customize->add_setting(
		'vastra_address',
		array(
			'default'           => __( 'Your studio address, City, Sri Lanka', 'vastra' ),
			'sanitize_callback' => 'sanitize_textarea_field',
		)
	);
	$wp_customize->add_control(
		'vastra_address',
		array(
			'section' => 'vastra_contact',
			'label'   => __( 'Studio address (placeholder)', 'vastra' ),
			'type'    => 'textarea',
		)
	);

	// ── Hero ───────────────────────────────────────────────────────────────
	$wp_customize->add_section(
		'vastra_hero',
		array(
			'title' => __( 'Homepage Hero', 'vastra' ),
			'panel' => 'vastra_store',
		)
	);

	$wp_customize->add_setting(
		'vastra_hero_image',
		array(
			'default'           => '',
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Media_Control(
			$wp_customize,
			'vastra_hero_image',
			array(
				'section'   => 'vastra_hero',
				'label'     => __( 'Hero image', 'vastra' ),
				'mime_type' => 'image',
			)
		)
	);

	$wp_customize->add_setting(
		'vastra_hero_title',
		array(
			'default'           => __( 'Celebrate Every Performance with VASTRA', 'vastra' ),
			'sanitize_callback' => 'sanitize_text_field',
		)
	);
	$wp_customize->add_control(
		'vastra_hero_title',
		array(
			'section' => 'vastra_hero',
			'label'   => __( 'Hero headline', 'vastra' ),
			'type'    => 'text',
		)
	);

	$wp_customize->add_setting(
		'vastra_hero_subtitle',
		array(
			'default'           => __( 'Handcrafted Kandyan, Low Country, Sabaragamuwa and Bharatanatyam costumes — tailored in Sri Lanka, delivered island-wide.', 'vastra' ),
			'sanitize_callback' => 'sanitize_textarea_field',
		)
	);
	$wp_customize->add_control(
		'vastra_hero_subtitle',
		array(
			'section' => 'vastra_hero',
			'label'   => __( 'Hero subheadline', 'vastra' ),
			'type'    => 'textarea',
		)
	);

	// ── Delivery strip ─────────────────────────────────────────────────────
	$wp_customize->add_section(
		'vastra_delivery',
		array(
			'title' => __( 'Delivery Information', 'vastra' ),
			'panel' => 'vastra_store',
		)
	);

	$wp_customize->add_setting(
		'vastra_delivery_text',
		array(
			'default'           => __( 'Island-wide delivery across Sri Lanka. Dispatch within 2–4 working days for ready-made costumes; custom orders are scheduled after measurement confirmation. Delivery fees are calculated at checkout by district.', 'vastra' ),
			'sanitize_callback' => 'sanitize_textarea_field',
		)
	);
	$wp_customize->add_control(
		'vastra_delivery_text',
		array(
			'section'     => 'vastra_delivery',
			'label'       => __( 'Delivery information (placeholder — edit to match your real policy)', 'vastra' ),
			'type'        => 'textarea',
		)
	);

	// ── SEO ────────────────────────────────────────────────────────────────
	$wp_customize->add_setting(
		'vastra_meta_description',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_textarea_field',
		)
	);
	$wp_customize->add_control(
		'vastra_meta_description',
		array(
			'section' => 'vastra_delivery',
			'label'   => __( 'Site meta description (SEO)', 'vastra' ),
			'type'    => 'textarea',
		)
	);

	// ── Social ─────────────────────────────────────────────────────────────
	$wp_customize->add_section(
		'vastra_social',
		array(
			'title' => __( 'Social Links', 'vastra' ),
			'panel' => 'vastra_store',
		)
	);

	foreach ( array( 'facebook', 'instagram', 'tiktok', 'youtube' ) as $network ) {
		$wp_customize->add_setting(
			'vastra_social_' . $network,
			array(
				'default'           => '',
				'sanitize_callback' => 'esc_url_raw',
			)
		);
		$wp_customize->add_control(
			'vastra_social_' . $network,
			array(
				'section'     => 'vastra_social',
				/* translators: %s: social network name. */
				'label'       => sprintf( __( '%s URL (placeholder)', 'vastra' ), ucfirst( $network ) ),
				'description' => __( 'Leave empty to hide the icon.', 'vastra' ),
				'type'        => 'url',
			)
		);
	}
}
add_action( 'customize_register', 'vastra_customize_register' );

/**
 * Sanitize a phone number: keep digits and a leading +.
 */
function vastra_sanitize_phone( $value ) {
	$value = (string) $value;
	$plus  = 0 === strpos( trim( $value ), '+' ) ? '+' : '';
	return $plus . preg_replace( '/\D+/', '', $value );
}

/**
 * Keep the Customizer WhatsApp number and the plugin option in sync.
 */
function vastra_sync_whatsapp_option( $wp_customize = null ) {
	$mod = get_theme_mod( 'vastra_whatsapp_number', '' );
	if ( $mod ) {
		update_option( 'vastra_whatsapp_number', preg_replace( '/\D+/', '', $mod ) );
	}
}
add_action( 'customize_save_after', 'vastra_sync_whatsapp_option' );
