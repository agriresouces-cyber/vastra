<?php
/**
 * VASTRA theme functions.
 *
 * @package VASTRA
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'VASTRA_VERSION', '1.0.0' );
define( 'VASTRA_DIR', get_template_directory() );
define( 'VASTRA_URI', get_template_directory_uri() );

require VASTRA_DIR . '/inc/template-tags.php';
require VASTRA_DIR . '/inc/customizer.php';
require VASTRA_DIR . '/inc/woocommerce.php';

/**
 * Theme setup.
 */
function vastra_setup() {
	load_theme_textdomain( 'vastra', VASTRA_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
	);
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 120,
			'width'       => 360,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	// WooCommerce.
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

	register_nav_menus(
		array(
			'primary' => __( 'Primary Menu', 'vastra' ),
			'footer'  => __( 'Footer Menu', 'vastra' ),
		)
	);

	// Optimised, reusable image sizes (mobile-first srcset does the rest).
	add_image_size( 'vastra-card', 640, 800, true );
	add_image_size( 'vastra-card-2x', 1280, 1600, true );
	add_image_size( 'vastra-hero', 2048, 1152, true );
}
add_action( 'after_setup_theme', 'vastra_setup' );

/**
 * Register widget areas.
 */
function vastra_widgets_init() {
	register_sidebar(
		array(
			'name'          => __( 'Shop Sidebar', 'vastra' ),
			'id'            => 'shop-sidebar',
			'description'   => __( 'Optional sidebar on shop archives.', 'vastra' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);
}
add_action( 'widgets_init', 'vastra_widgets_init' );

/**
 * Enqueue assets.
 */
function vastra_assets() {
	// Fonts: display serif + geometric sans, with preconnect + swap for speed.
	wp_enqueue_style(
		'vastra-fonts',
		'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,600&family=Jost:ital,wght@0,300;0,400;0,500;0,600;1,400&display=swap',
		array(),
		null
	);

	wp_enqueue_style( 'vastra-main', VASTRA_URI . '/assets/css/main.css', array( 'vastra-fonts' ), VASTRA_VERSION );

	wp_enqueue_script( 'vastra-main', VASTRA_URI . '/assets/js/main.js', array(), VASTRA_VERSION, true );

	wp_localize_script(
		'vastra-main',
		'vastraData',
		array(
			'whatsappNumber' => vastra_whatsapp_number(),
			'i18n'           => array(
				'menuOpen'  => __( 'Open menu', 'vastra' ),
				'menuClose' => __( 'Close menu', 'vastra' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'vastra_assets' );

/**
 * Preconnect to Google Fonts; defer theme JS.
 */
function vastra_resource_hints( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type ) {
		$urls[] = array( 'href' => 'https://fonts.googleapis.com' );
		$urls[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => 'crossorigin',
		);
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'vastra_resource_hints', 10, 2 );

/**
 * Defer non-critical theme script.
 */
function vastra_defer_scripts( $tag, $handle ) {
	if ( 'vastra-main' === $handle ) {
		return str_replace( ' src', ' defer src', $tag );
	}
	return $tag;
}
add_filter( 'script_loader_tag', 'vastra_defer_scripts', 10, 2 );

/**
 * Basic SEO meta + Open Graph + Organization schema.
 * (A dedicated SEO plugin can be layered on top; these are sensible defaults.)
 */
function vastra_seo_meta() {
	$description = get_theme_mod(
		'vastra_meta_description',
		__( 'VASTRA — premium Sri Lankan dance costumes: Kandyan, Low Country, Sabaragamuwa, Bharatanatyam, school dance costumes, stage wear and custom-made outfits. Island-wide delivery across Sri Lanka.', 'vastra' )
	);
	if ( is_singular() ) {
		$excerpt = get_the_excerpt();
		if ( $excerpt ) {
			$description = wp_strip_all_tags( $excerpt );
		}
	}
	echo '<meta name="description" content="' . esc_attr( $description ) . '">' . "\n";
	echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( wp_get_document_title() ) . '">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $description ) . '">' . "\n";
	echo '<meta property="og:type" content="' . ( is_singular( 'product' ) ? 'product' : 'website' ) . '">' . "\n";
	echo '<meta property="og:locale" content="en_LK">' . "\n";
	if ( is_singular() && has_post_thumbnail() ) {
		echo '<meta property="og:image" content="' . esc_url( get_the_post_thumbnail_url( null, 'large' ) ) . '">' . "\n";
	}

	$schema = array(
		'@context' => 'https://schema.org',
		'@type'    => 'ClothingStore',
		'name'     => get_bloginfo( 'name' ),
		'url'      => home_url( '/' ),
		'areaServed' => 'LK',
	);
	if ( has_custom_logo() ) {
		$logo = wp_get_attachment_image_src( get_theme_mod( 'custom_logo' ), 'full' );
		if ( $logo ) {
			$schema['logo'] = $logo[0];
		}
	}
	echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>' . "\n";
}
add_action( 'wp_head', 'vastra_seo_meta', 5 );

/**
 * Body classes.
 */
function vastra_body_classes( $classes ) {
	$classes[] = 'vastra';
	if ( ! has_custom_logo() ) {
		$classes[] = 'vastra-no-logo';
	}
	return $classes;
}
add_filter( 'body_class', 'vastra_body_classes' );

/**
 * Excerpt length.
 */
function vastra_excerpt_length( $length ) {
	return 22;
}
add_filter( 'excerpt_length', 'vastra_excerpt_length' );
