/**
 * VASTRA theme interactions: mobile navigation.
 * Deferred; no jQuery dependency.
 */
(function () {
	'use strict';

	var toggle = document.getElementById('nav-toggle');
	var nav = document.getElementById('primary-nav');
	if (!toggle || !nav) {
		return;
	}

	var backdrop = document.createElement('div');
	backdrop.className = 'nav-backdrop';
	document.body.appendChild(backdrop);

	function setMenu(open) {
		toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
		toggle.setAttribute(
			'aria-label',
			open
				? (window.vastraData && vastraData.i18n.menuClose) || 'Close menu'
				: (window.vastraData && vastraData.i18n.menuOpen) || 'Open menu'
		);
		nav.classList.toggle('nav-open', open);
		backdrop.classList.toggle('nav-open', open);
		document.body.classList.toggle('nav-locked', open);
	}

	toggle.addEventListener('click', function () {
		setMenu(toggle.getAttribute('aria-expanded') !== 'true');
	});
	backdrop.addEventListener('click', function () {
		setMenu(false);
	});
	document.addEventListener('keydown', function (event) {
		if (event.key === 'Escape' && nav.classList.contains('nav-open')) {
			setMenu(false);
			toggle.focus();
		}
	});
	nav.addEventListener('click', function (event) {
		if (event.target.closest('a')) {
			setMenu(false);
		}
	});
})();
