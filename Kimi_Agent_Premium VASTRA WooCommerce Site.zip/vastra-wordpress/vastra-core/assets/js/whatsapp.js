/**
 * VASTRA Core — WhatsApp order link builder.
 * On click, rebuilds the wa.me message with the shopper's live selection:
 * product name, code (SKU), size, colour, quantity and product URL.
 */
(function () {
	'use strict';

	var button = document.querySelector('[data-vastra-wa]');
	if (!button) {
		return;
	}

	button.addEventListener('click', function (event) {
		var number = button.getAttribute('data-number');
		if (!number) {
			return;
		}
		event.preventDefault();

		var name = button.getAttribute('data-name') || '';
		var sku = button.getAttribute('data-sku') || '';
		var url = button.getAttribute('data-url') || window.location.href;
		var labels = {};
		try {
			labels = JSON.parse(button.getAttribute('data-attributes') || '{}');
		} catch (e) {
			labels = {};
		}

		var lines = [];
		lines.push('Hello VASTRA! I would like to order:');
		lines.push('*' + name + '*' + (sku ? ' (Code: ' + sku + ')' : ''));

		// Selected variation attributes (size, colour, …).
		var form = button.closest('.product') || document;
		var selects = form.querySelectorAll('table.variations select, .variations select');
		selects.forEach(function (select) {
			if (!select.value) {
				return;
			}
			var label = labels[select.name] || select.name.replace(/^attribute_/, '').replace(/^pa_/, '');
			var text = select.options[select.selectedIndex]
				? select.options[select.selectedIndex].text
				: select.value;
			lines.push(label.charAt(0).toUpperCase() + label.slice(1) + ': ' + text);
		});

		var qty = form.querySelector('.quantity input.qty, input[name="quantity"]');
		var quantity = qty && qty.value ? parseInt(qty.value, 10) : 1;
		lines.push('Quantity: ' + (isNaN(quantity) ? 1 : quantity));
		lines.push(url);

		window.open('https://wa.me/' + number + '?text=' + encodeURIComponent(lines.join('\n')), '_blank', 'noopener');
	});
})();
