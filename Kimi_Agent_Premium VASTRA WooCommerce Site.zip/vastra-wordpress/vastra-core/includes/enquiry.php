<?php
/**
 * VASTRA Core — custom costume enquiry form.
 *
 * Shortcode: [vastra_custom_order_form]
 * Stores enquiries in a private CPT, emails the store, and offers a WhatsApp hand-off.
 *
 * @package VASTRA_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Private post type for enquiries (visible in WP Admin → VASTRA Store → Enquiries).
 */
function vastra_core_register_enquiry_cpt() {
	register_post_type(
		'vastra_enquiry',
		array(
			'labels'       => array(
				'name'          => __( 'Custom Enquiries', 'vastra-core' ),
				'singular_name' => __( 'Custom Enquiry', 'vastra-core' ),
			),
			'public'       => false,
			'show_ui'      => true,
			'show_in_menu' => 'vastra-store',
			'supports'     => array( 'title', 'editor' ),
			'capability_type' => 'post',
		)
	);
}
add_action( 'init', 'vastra_core_register_enquiry_cpt' );

/**
 * Shortcode renderer.
 */
function vastra_core_enquiry_shortcode() {
	$status  = isset( $_GET['vastra_enquiry'] ) ? sanitize_key( wp_unslash( $_GET['vastra_enquiry'] ) ) : '';
	$message = isset( $_GET['vastra_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['vastra_msg'] ) ) : '';

	$costume_types = array(
		'Kandyan',
		'Low Country',
		'Sabaragamuwa',
		'Bharatanatyam',
		'School / Children’s dance',
		'Stage wear',
		'Accessories',
		'Other / not sure',
	);

	ob_start();
	?>
	<form class="vastra-enquiry" method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php if ( 'success' === $status ) : ?>
			<div class="form-success" role="status">
				<?php esc_html_e( 'Thank you! Your custom costume enquiry has been received. We will contact you shortly to confirm details and pricing.', 'vastra-core' ); ?>
				<?php
				$wa = vastra_core_option( 'vastra_whatsapp_number' );
				if ( $wa ) :
					?>
					<br><a class="text-link" href="<?php echo esc_url( 'https://wa.me/' . $wa . '?text=' . rawurlencode( __( 'Hello VASTRA! I just submitted a custom costume enquiry.', 'vastra-core' ) ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Continue on WhatsApp for a faster reply', 'vastra-core' ); ?></a>
				<?php endif; ?>
			</div>
		<?php elseif ( 'error' === $status ) : ?>
			<div class="form-error" role="alert"><?php echo esc_html( $message ? $message : __( 'Please check the highlighted fields and try again.', 'vastra-core' ) ); ?></div>
		<?php endif; ?>

		<input type="hidden" name="action" value="vastra_enquiry">
		<?php wp_nonce_field( 'vastra_enquiry_submit', 'vastra_enquiry_nonce' ); ?>
		<p class="hp-field" aria-hidden="true">
			<label><?php esc_html_e( 'Leave this field empty', 'vastra-core' ); ?>
				<input type="text" name="vastra_website" value="" tabindex="-1" autocomplete="off">
			</label>
		</p>

		<fieldset>
			<legend><?php esc_html_e( 'Your details', 'vastra-core' ); ?></legend>
			<div class="field-row">
				<div class="field">
					<label for="ve_name"><?php esc_html_e( 'Full name', 'vastra-core' ); ?> *</label>
					<input type="text" id="ve_name" name="ve_name" required maxlength="120">
				</div>
				<div class="field">
					<label for="ve_phone"><?php esc_html_e( 'Phone (WhatsApp preferred)', 'vastra-core' ); ?> *</label>
					<input type="tel" id="ve_phone" name="ve_phone" required maxlength="20" inputmode="tel">
				</div>
			</div>
			<div class="field">
				<label for="ve_email"><?php esc_html_e( 'Email (optional)', 'vastra-core' ); ?></label>
				<input type="email" id="ve_email" name="ve_email" maxlength="120">
			</div>
		</fieldset>

		<fieldset>
			<legend><?php esc_html_e( 'Costume details', 'vastra-core' ); ?></legend>
			<div class="field-row">
				<div class="field">
					<label for="ve_type"><?php esc_html_e( 'Costume type', 'vastra-core' ); ?> *</label>
					<select id="ve_type" name="ve_type" required>
						<option value=""><?php esc_html_e( 'Select a type', 'vastra-core' ); ?></option>
						<?php foreach ( $costume_types as $type ) : ?>
							<option value="<?php echo esc_attr( $type ); ?>"><?php echo esc_html( $type ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="field">
					<label for="ve_colour"><?php esc_html_e( 'Preferred colour(s)', 'vastra-core' ); ?></label>
					<input type="text" id="ve_colour" name="ve_colour" maxlength="120" placeholder="<?php esc_attr_e( 'e.g. maroon & gold', 'vastra-core' ); ?>">
				</div>
			</div>
			<div class="field-row">
				<div class="field">
					<label for="ve_qty"><?php esc_html_e( 'Quantity', 'vastra-core' ); ?> *</label>
					<input type="number" id="ve_qty" name="ve_qty" min="1" max="500" value="1" required>
				</div>
				<div class="field">
					<label for="ve_date"><?php esc_html_e( 'Required by (performance date)', 'vastra-core' ); ?> *</label>
					<input type="date" id="ve_date" name="ve_date" required min="<?php echo esc_attr( gmdate( 'Y-m-d', strtotime( '+3 days' ) ) ); ?>">
				</div>
			</div>
			<div class="field">
				<label for="ve_measurements"><?php esc_html_e( 'Measurements', 'vastra-core' ); ?> *</label>
				<textarea id="ve_measurements" name="ve_measurements" rows="4" required placeholder="<?php esc_attr_e( 'Chest / waist / hip / height / shoulder (cm or inches). For groups, list sizes per dancer.', 'vastra-core' ); ?>"></textarea>
				<p class="hint"><?php esc_html_e( 'Not sure? Give your best estimate — we confirm measurements with you before cutting.', 'vastra-core' ); ?></p>
			</div>
			<div class="field">
				<label for="ve_notes"><?php esc_html_e( 'Design notes (optional)', 'vastra-core' ); ?></label>
				<textarea id="ve_notes" name="ve_notes" rows="3" placeholder="<?php esc_attr_e( 'Beadwork, sleeve length, matching accessories…', 'vastra-core' ); ?>"></textarea>
			</div>
			<div class="field">
				<label for="ve_refs"><?php esc_html_e( 'Reference images (optional, up to 3)', 'vastra-core' ); ?></label>
				<input type="file" id="ve_refs" name="ve_refs[]" accept="image/jpeg,image/png,image/webp" multiple>
				<p class="hint"><?php esc_html_e( 'JPG, PNG or WebP, max 5 MB each.', 'vastra-core' ); ?></p>
			</div>
		</fieldset>

		<button type="submit" class="btn btn--gold"><?php esc_html_e( 'Send Custom Enquiry', 'vastra-core' ); ?></button>
	</form>
	<?php
	return ob_get_clean();
}
add_shortcode( 'vastra_custom_order_form', 'vastra_core_enquiry_shortcode' );

/**
 * Handle submission (guests + logged-in).
 */
add_action( 'admin_post_nopriv_vastra_enquiry', 'vastra_core_handle_enquiry' );
add_action( 'admin_post_vastra_enquiry', 'vastra_core_handle_enquiry' );
function vastra_core_handle_enquiry() {
	$back = wp_get_referer() ? wp_get_referer() : home_url( '/custom-orders/' );
	$fail = function ( $msg ) use ( $back ) {
		wp_safe_redirect( add_query_arg( array( 'vastra_enquiry' => 'error', 'vastra_msg' => rawurlencode( $msg ) ), $back ) );
		exit;
	};

	if ( ! isset( $_POST['vastra_enquiry_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['vastra_enquiry_nonce'] ) ), 'vastra_enquiry_submit' ) ) {
		$fail( __( 'Security check failed. Please try again.', 'vastra-core' ) );
	}

	// Honeypot.
	if ( ! empty( $_POST['vastra_website'] ) ) {
		$fail( __( 'Spam detected.', 'vastra-core' ) );
	}

	$name         = isset( $_POST['ve_name'] ) ? sanitize_text_field( wp_unslash( $_POST['ve_name'] ) ) : '';
	$phone        = isset( $_POST['ve_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['ve_phone'] ) ) : '';
	$email        = isset( $_POST['ve_email'] ) ? sanitize_email( wp_unslash( $_POST['ve_email'] ) ) : '';
	$type         = isset( $_POST['ve_type'] ) ? sanitize_text_field( wp_unslash( $_POST['ve_type'] ) ) : '';
	$colour       = isset( $_POST['ve_colour'] ) ? sanitize_text_field( wp_unslash( $_POST['ve_colour'] ) ) : '';
	$qty          = isset( $_POST['ve_qty'] ) ? absint( $_POST['ve_qty'] ) : 0;
	$date         = isset( $_POST['ve_date'] ) ? sanitize_text_field( wp_unslash( $_POST['ve_date'] ) ) : '';
	$measurements = isset( $_POST['ve_measurements'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ve_measurements'] ) ) : '';
	$notes        = isset( $_POST['ve_notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ve_notes'] ) ) : '';

	if ( ! $name || ! $phone || ! $type || ! $qty || ! $date || ! $measurements ) {
		$fail( __( 'Please complete all required fields.', 'vastra-core' ) );
	}
	if ( strtotime( $date ) < strtotime( 'today' ) ) {
		$fail( __( 'The required-by date cannot be in the past.', 'vastra-core' ) );
	}

	$body = sprintf(
		"Name: %s\nPhone: %s\nEmail: %s\nCostume type: %s\nColour: %s\nQuantity: %d\nRequired by: %s\n\nMeasurements:\n%s\n\nDesign notes:\n%s\n",
		$name,
		$phone,
		$email ? $email : '—',
		$type,
		$colour ? $colour : '—',
		$qty,
		$date,
		$measurements,
		$notes ? $notes : '—'
	);

	$post_id = wp_insert_post(
		array(
			'post_type'    => 'vastra_enquiry',
			'post_status'  => 'private',
			/* translators: 1: customer name, 2: date. */
			'post_title'   => sprintf( __( '%1$s — %2$s', 'vastra-core' ), $name, $date ),
			'post_content' => $body,
		),
		true
	);
	if ( is_wp_error( $post_id ) ) {
		$fail( __( 'Could not save your enquiry. Please try WhatsApp instead.', 'vastra-core' ) );
	}

	// Reference images (optional, max 3, images only, 5 MB each).
	if ( ! empty( $_FILES['ve_refs']['name'][0] ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$allowed = array( 'image/jpeg', 'image/png', 'image/webp' );
		$count   = min( 3, count( $_FILES['ve_refs']['name'] ) );
		$attached = 0;
		for ( $i = 0; $i < $count; $i++ ) {
			if ( empty( $_FILES['ve_refs']['name'][ $i ] ) || $_FILES['ve_refs']['size'][ $i ] > 5 * MB_IN_BYTES ) {
				continue;
			}
			$type_mime = mime_content_type( $_FILES['ve_refs']['tmp_name'][ $i ] );
			if ( ! in_array( $type_mime, $allowed, true ) ) {
				continue;
			}
			$file = array(
				'name'     => sanitize_file_name( $_FILES['ve_refs']['name'][ $i ] ),
				'type'     => $type_mime,
				'tmp_name' => $_FILES['ve_refs']['tmp_name'][ $i ],
				'error'    => $_FILES['ve_refs']['error'][ $i ],
				'size'     => $_FILES['ve_refs']['size'][ $i ],
			);
			$attach_id = media_handle_sideload( $file, $post_id );
			if ( ! is_wp_error( $attach_id ) ) {
				$attached++;
			}
		}
		if ( $attached ) {
			$body .= "\nReference images attached: {$attached} (see Media Library)";
			wp_update_post( array( 'ID' => $post_id, 'post_content' => $body ) );
		}
	}

	// Notify the store.
	$admin_email = get_option( 'admin_email' );
	wp_mail(
		$admin_email,
		sprintf( __( '[VASTRA] New custom costume enquiry — %s', 'vastra-core' ), $name ),
		$body . "\nView: " . admin_url( 'post.php?post=' . $post_id . '&action=edit' ),
		array( 'Reply-To: ' . ( $email ? $email : $admin_email ) )
	);

	wp_safe_redirect( add_query_arg( 'vastra_enquiry', 'success', $back ) );
	exit;
}
