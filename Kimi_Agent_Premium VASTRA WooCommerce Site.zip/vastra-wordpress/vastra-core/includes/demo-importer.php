<?php
/**
 * VASTRA Core — one-click demo content importer.
 *
 * Creates editable demo products (LKR prices, stock, variations), categories,
 * policy pages (clearly marked placeholders), menus, and WooCommerce defaults.
 *
 * @package VASTRA_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin submenu page.
 */
function vastra_core_demo_menu() {
	add_submenu_page(
		'vastra-store',
		__( 'Demo Content', 'vastra-core' ),
		__( 'Demo Content', 'vastra-core' ),
		'manage_options',
		'vastra-demo',
		'vastra_core_demo_page'
	);
}
add_action( 'admin_menu', 'vastra_core_demo_menu' );

/**
 * Demo page HTML + action handling.
 */
function vastra_core_demo_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$done = get_option( 'vastra_demo_installed' );
	$log  = array();

	if ( isset( $_POST['vastra_demo_run'] ) && check_admin_referer( 'vastra_demo_run' ) ) {
		if ( ! class_exists( 'WooCommerce' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'WooCommerce must be installed and active first.', 'vastra-core' ) . '</p></div>';
		} else {
			$log = vastra_core_run_demo_import();
			update_option( 'vastra_demo_installed', gmdate( 'c' ) );
			$done = get_option( 'vastra_demo_installed' );
		}
	}
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'VASTRA Demo Content', 'vastra-core' ); ?></h1>
		<p><?php esc_html_e( 'Creates editable demo data so you can see the store working immediately, then replace it with your real catalogue:', 'vastra-core' ); ?></p>
		<ul style="list-style:disc;padding-left:22px">
			<li><?php esc_html_e( '8 product categories (Kandyan, Low Country, Sabaragamuwa, Bharatanatyam, School & Kids, Stage Wear, Accessories, Custom-Made)', 'vastra-core' ); ?></li>
			<li><?php esc_html_e( '15 demo products with LKR prices, SKUs, stock and size/colour variations (no fake reviews or credentials)', 'vastra-core' ); ?></li>
			<li><?php esc_html_e( 'Pages: Custom Orders, Shipping & Delivery, Returns & Exchanges, Privacy Policy, Terms & Conditions (placeholder text)', 'vastra-core' ); ?></li>
			<li><?php esc_html_e( 'Menus, homepage assignment, LKR currency, Sri Lanka address, Cash on Delivery + Bank Transfer (placeholder details), island-wide flat-rate shipping', 'vastra-core' ); ?></li>
		</ul>
		<p><strong><?php esc_html_e( 'Safe to re-run:', 'vastra-core' ); ?></strong> <?php esc_html_e( 'existing items are detected by SKU/slug and skipped, not duplicated.', 'vastra-core' ); ?></p>
		<form method="post">
			<?php wp_nonce_field( 'vastra_demo_run' ); ?>
			<?php submit_button( __( 'Install / refresh demo content', 'vastra-core' ), 'primary', 'vastra_demo_run' ); ?>
		</form>
		<?php if ( $done ) : ?>
			<p class="description"><?php printf( /* translators: %s: date */ esc_html__( 'Last run: %s', 'vastra-core' ), esc_html( $done ) ); ?></p>
		<?php endif; ?>
		<?php foreach ( $log as $line ) : ?>
			<p>✅ <?php echo esc_html( $line ); ?></p>
		<?php endforeach; ?>
	</div>
	<?php
}

/**
 * Sideload a bundled image into the Media Library (idempotent by filename).
 *
 * @return int Attachment ID or 0.
 */
function vastra_core_import_image( $filename ) {
	$source = VASTRA_CORE_DIR . 'assets/images/' . $filename;
	if ( ! file_exists( $source ) ) {
		return 0;
	}
	$existing = get_posts(
		array(
			'post_type'   => 'attachment',
			'name'        => sanitize_title( pathinfo( $filename, PATHINFO_FILENAME ) ),
			'numberposts' => 1,
			'fields'      => 'ids',
		)
	);
	if ( $existing ) {
		return (int) $existing[0];
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$tmp = wp_tempnam( $filename );
	copy( $source, $tmp );
	$attachment_id = media_handle_sideload(
		array(
			'name'     => $filename,
			'tmp_name' => $tmp,
		),
		0
	);
	if ( is_wp_error( $attachment_id ) ) {
		@unlink( $tmp );
		return 0;
	}
	return (int) $attachment_id;
}

/**
 * Ensure a product category exists; return term ID.
 */
function vastra_core_ensure_category( $name, $slug, $image_file = '' ) {
	$term = term_exists( $slug, 'product_cat' );
	if ( ! $term ) {
		$term = wp_insert_term( $name, 'product_cat', array( 'slug' => $slug ) );
	}
	if ( is_wp_error( $term ) ) {
		return 0;
	}
	$term_id = (int) ( is_array( $term ) ? $term['term_id'] : $term );
	if ( $image_file && ! get_term_meta( $term_id, 'thumbnail_id', true ) ) {
		$thumb = vastra_core_import_image( $image_file );
		if ( $thumb ) {
			update_term_meta( $term_id, 'thumbnail_id', $thumb );
		}
	}
	return $term_id;
}

/**
 * Create or update a demo product. Detects existing products by SKU.
 */
function vastra_core_upsert_product( $data ) {
	$product_id = wc_get_product_id_by_sku( $data['sku'] );
	if ( $product_id ) {
		return $product_id; // Already imported — leave merchant edits untouched.
	}

	$is_variable = ! empty( $data['sizes'] );
	$product     = $is_variable ? new WC_Product_Variable() : new WC_Product_Simple();

	$product->set_name( $data['name'] );
	$product->set_slug( sanitize_title( $data['name'] ) );
	$product->set_sku( $data['sku'] );
	$product->set_status( 'publish' );
	$product->set_catalog_visibility( 'visible' );
	$product->set_description( $data['description'] );
	$product->set_short_description( $data['short'] );
	$product->set_regular_price( (string) $data['price'] );
	if ( ! empty( $data['sale_price'] ) ) {
		$product->set_sale_price( (string) $data['sale_price'] );
	}
	$product->set_category_ids( array( $data['category_id'] ) );
	if ( ! empty( $data['tags'] ) ) {
		$product->set_tag_ids( array_map( 'vastra_core_ensure_tag', $data['tags'] ) );
	}

	// Image.
	if ( ! empty( $data['image'] ) ) {
		$image_id = vastra_core_import_image( $data['image'] );
		if ( $image_id ) {
			$product->set_image_id( $image_id );
		}
	}

	if ( $is_variable ) {
		$size_attr = new WC_Product_Attribute();
		$size_attr->set_name( 'Size' );
		$size_attr->set_options( $data['sizes'] );
		$size_attr->set_position( 0 );
		$size_attr->set_visible( true );
		$size_attr->set_variation( true );

		$attributes = array( $size_attr );
		$colours    = ! empty( $data['colours'] ) ? $data['colours'] : array();
		if ( $colours ) {
			$colour_attr = new WC_Product_Attribute();
			$colour_attr->set_name( 'Colour' );
			$colour_attr->set_options( $colours );
			$colour_attr->set_position( 1 );
			$colour_attr->set_visible( true );
			$colour_attr->set_variation( true );
			$attributes[] = $colour_attr;
		}
		$product->set_attributes( $attributes );
		$product->save();

		$combos = array( array() );
		foreach ( $data['sizes'] as $size ) {
			if ( $colours ) {
				foreach ( $colours as $colour ) {
					$combos[] = array( 'size' => $size, 'colour' => $colour );
				}
			} else {
				$combos[] = array( 'size' => $size );
			}
		}
		$combos = array_filter( $combos );
		foreach ( $combos as $combo ) {
			$variation = new WC_Product_Variation();
			$variation->set_parent_id( $product->get_id() );
			$attrs = array();
			if ( isset( $combo['size'] ) ) {
				$attrs['size'] = $combo['size'];
			}
			if ( isset( $combo['colour'] ) ) {
				$attrs['colour'] = $combo['colour'];
			}
			$variation->set_attributes( $attrs );
			$variation->set_regular_price( (string) $data['price'] );
			if ( ! empty( $data['sale_price'] ) ) {
				$variation->set_sale_price( (string) $data['sale_price'] );
			}
			$variation->set_manage_stock( true );
			$variation->set_stock_quantity( $data['variation_stock'] ?? 3 );
			$variation->set_status( 'publish' );
			$variation->save();
		}
		WC_Product_Variable::sync( $product->get_id() );
	} else {
		$product->set_manage_stock( true );
		$product->set_stock_quantity( $data['stock'] ?? 10 );
		$product->save();
	}

	return $product->get_id();
}

/**
 * Ensure a product tag exists; return term ID.
 */
function vastra_core_ensure_tag( $slug ) {
	$term = term_exists( $slug, 'product_tag' );
	if ( ! $term ) {
		$term = wp_insert_term( ucwords( str_replace( '-', ' ', $slug ) ), 'product_tag', array( 'slug' => $slug ) );
	}
	return is_wp_error( $term ) ? 0 : (int) ( is_array( $term ) ? $term['term_id'] : $term );
}

/**
 * Run the demo import.
 *
 * @return string[] Log lines.
 */
function vastra_core_run_demo_import() {
	$log = array();

	// ── Categories ────────────────────────────────────────────────────────
	$categories = array(
		'kandyan'       => array( 'Kandyan', 'kandyan-1.jpg' ),
		'low-country'   => array( 'Low Country', 'lowcountry-1.jpg' ),
		'sabaragamuwa'  => array( 'Sabaragamuwa', 'sabaragamuwa-1.jpg' ),
		'bharatanatyam' => array( 'Bharatanatyam', 'bharatanatyam-1.jpg' ),
		'school-kids'   => array( 'School & Kids', 'kids-1.jpg' ),
		'stage-wear'    => array( 'Stage Wear', 'stagewear-1.jpg' ),
		'accessories'   => array( 'Accessories', 'accessories-1.jpg' ),
		'custom-made'   => array( 'Custom-Made', 'custom-1.jpg' ),
	);
	$cat_ids = array();
	foreach ( $categories as $slug => $row ) {
		$cat_ids[ $slug ] = vastra_core_ensure_category( $row[0], $slug, $row[1] );
	}
	$log[] = __( 'Categories ready (8).', 'vastra-core' );

	// ── Products ──────────────────────────────────────────────────────────
	$adult_sizes = array( 'XS', 'S', 'M', 'L', 'XL' );
	$kids_sizes  = array( '4-6 yrs', '7-9 yrs', '10-12 yrs', '13-15 yrs' );
	$desc_tail   = "\n\nEach VASTRA costume is cut, stitched and finished by hand in Sri Lanka. Colours and beadwork can be customised — use the Custom Orders form or message us on WhatsApp. (Demo product: edit or replace with your own catalogue.)";

	$products = array(
		array( 'name' => 'Kandyan Ves Costume — Classic', 'sku' => 'VAS-KAN-001', 'cat' => 'kandyan', 'price' => 38500, 'sale_price' => 34500, 'sizes' => $adult_sizes, 'colours' => array( 'Maroon & Gold', 'Ivory & Silver' ), 'image' => 'kandyan-1.jpg', 'tags' => array( 'best-seller' ), 'short' => 'The traditional up-country ves costume with ornate chest plate and beadwork.' ),
		array( 'name' => 'Kandyan Rajya Costume — Women', 'sku' => 'VAS-KAN-002', 'cat' => 'kandyan', 'price' => 42500, 'sizes' => $adult_sizes, 'colours' => array( 'Maroon & Gold', 'Black & Gold' ), 'image' => 'kandyan-2.jpg', 'tags' => array( 'new' ), 'short' => 'Elegant women’s Kandyan jacket with gold border work and flowing wrap.' ),
		array( 'name' => 'Low Country Devil Dance Costume', 'sku' => 'VAS-LOW-001', 'cat' => 'low-country', 'price' => 36000, 'sizes' => $adult_sizes, 'colours' => array( 'Red & Black', 'Maroon & Gold' ), 'image' => 'lowcountry-1.jpg', 'tags' => array( 'best-seller' ), 'short' => 'Bold traditional low-country costume; matching mask available on request.' ),
		array( 'name' => 'Kolam Dance Costume', 'sku' => 'VAS-LOW-002', 'cat' => 'low-country', 'price' => 34500, 'sizes' => $adult_sizes, 'colours' => array( 'Crimson & Gold' ), 'image' => 'lowcountry-2.jpg', 'tags' => array( 'new' ), 'short' => 'Wide pleated kolam silhouette in crimson and gold.' ),
		array( 'name' => 'Sabaragamuwa Costume — Men', 'sku' => 'VAS-SAB-001', 'cat' => 'sabaragamuwa', 'price' => 36500, 'sizes' => $adult_sizes, 'colours' => array( 'Red & Gold' ), 'image' => 'sabaragamuwa-1.jpg', 'tags' => array(), 'short' => 'Traditional Sabaragamuwa jacket with bead tassels and drum belt.' ),
		array( 'name' => 'Sabaragamuwa Costume — Women', 'sku' => 'VAS-SAB-002', 'cat' => 'sabaragamuwa', 'price' => 39800, 'sizes' => $adult_sizes, 'colours' => array( 'Crimson & Gold' ), 'image' => 'sabaragamuwa-2.jpg', 'tags' => array( 'best-seller' ), 'short' => 'Crimson silk blouse, gold border work and flowing white skirt with sash.' ),
		array( 'name' => 'Bharatanatyam Temple Silk — Maroon', 'sku' => 'VAS-BHA-001', 'cat' => 'bharatanatyam', 'price' => 44900, 'sale_price' => 41900, 'sizes' => $adult_sizes, 'colours' => array( 'Maroon & Gold' ), 'image' => 'bharatanatyam-1.jpg', 'tags' => array( 'best-seller' ), 'short' => 'Kanjivaram-style silk with stitched pleated fan for perfect araimandi lines.' ),
		array( 'name' => 'Bharatanatyam Dhavani — Emerald', 'sku' => 'VAS-BHA-002', 'cat' => 'bharatanatyam', 'price' => 46500, 'sizes' => $adult_sizes, 'colours' => array( 'Emerald & Gold', 'Maroon & Gold' ), 'image' => 'bharatanatyam-2.jpg', 'tags' => array( 'new' ), 'short' => 'Half-saree dhavani style in emerald silk with temple border.' ),
		array( 'name' => 'Junior Kandyan Set — School', 'sku' => 'VAS-KID-001', 'cat' => 'school-kids', 'price' => 18500, 'sizes' => $kids_sizes, 'colours' => array( 'White & Maroon' ), 'image' => 'kids-1.jpg', 'tags' => array( 'best-seller' ), 'short' => 'Lightweight junior Kandyan set sized for school performers.' ),
		array( 'name' => 'School Folk Dance Set', 'sku' => 'VAS-KID-002', 'cat' => 'school-kids', 'price' => 16800, 'sizes' => $kids_sizes, 'colours' => array( 'Maroon & Ivory' ), 'image' => 'kids-2.jpg', 'tags' => array(), 'short' => 'Comfortable, durable folk set for school concerts and competitions.' ),
		array( 'name' => 'Maroon Sequin Stage Gown', 'sku' => 'VAS-STG-001', 'cat' => 'stage-wear', 'price' => 52000, 'sizes' => $adult_sizes, 'colours' => array( 'Maroon & Gold' ), 'image' => 'stagewear-1.jpg', 'tags' => array( 'new' ), 'short' => 'Flowing contemporary gown with sequin bodice — built for the spotlight.' ),
		array( 'name' => 'Maroon & Gold Stage Skirt', 'sku' => 'VAS-STG-002', 'cat' => 'stage-wear', 'price' => 48000, 'sizes' => $adult_sizes, 'colours' => array( 'Maroon & Gold' ), 'image' => 'stagewear-2.jpg', 'tags' => array(), 'short' => 'Flowing two-tone stage skirt with gold-edged drape — pairs with the sequin bodice.' ),
		array( 'name' => 'Temple Jewellery Set — 5 Piece', 'sku' => 'VAS-ACC-001', 'cat' => 'accessories', 'price' => 12500, 'sizes' => array(), 'image' => 'accessories-1.jpg', 'tags' => array( 'best-seller' ), 'stock' => 15, 'short' => 'Gold-tone headpiece, necklace, bangles and ear chains with red stones.' ),
		array( 'name' => 'Gejji Bells & Waist Belt', 'sku' => 'VAS-ACC-002', 'cat' => 'accessories', 'price' => 8900, 'sizes' => array(), 'image' => 'accessories-2.jpg', 'tags' => array(), 'stock' => 20, 'short' => 'Traditional anklet bells and matching waist belt for Kandyan dance.' ),
		array( 'name' => 'Custom-Made Costume — Booking Deposit', 'sku' => 'VAS-CUS-001', 'cat' => 'custom-made', 'price' => 5000, 'sizes' => array(), 'image' => 'custom-1.jpg', 'tags' => array(), 'stock' => 999, 'short' => 'Reserve your slot in the atelier. Final quote follows the Custom Orders form.' ),
	);

	$created = 0;
	foreach ( $products as $p ) {
		$id = vastra_core_upsert_product(
			array(
				'name'        => $p['name'],
				'sku'         => $p['sku'],
				'price'       => $p['price'],
				'sale_price'  => $p['sale_price'] ?? 0,
				'sizes'       => $p['sizes'],
				'colours'     => $p['colours'] ?? array(),
				'image'       => $p['image'],
				'tags'        => $p['tags'],
				'stock'       => $p['stock'] ?? 10,
				'category_id' => $cat_ids[ $p['cat'] ],
				'short'       => $p['short'],
				'description' => $p['short'] . $desc_tail,
			)
		);
		if ( $id ) {
			$created++;
		}
	}
	$log[] = sprintf( /* translators: %d: count */ __( 'Demo products processed (%d).', 'vastra-core' ), $created );

	// ── Pages ─────────────────────────────────────────────────────────────
	$pages = vastra_core_demo_pages();
	$log[] = sprintf( /* translators: %d: count */ __( 'Pages ready (%d).', 'vastra-core' ), count( $pages ) );

	// ── Homepage + menus ──────────────────────────────────────────────────
	if ( ! get_option( 'page_on_front' ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $pages['home'] );
	}
	vastra_core_demo_menus( $pages );
	$log[] = __( 'Homepage and menus assigned.', 'vastra-core' );

	// ── WooCommerce + store defaults ──────────────────────────────────────
	update_option( 'woocommerce_currency', 'LKR' );
	update_option( 'woocommerce_default_country', 'LK' );
	update_option( 'woocommerce_allowed_countries', 'specific' );
	update_option( 'woocommerce_specific_allowed_countries', array( 'LK' ) );
	update_option( 'woocommerce_ship_to_countries', 'specific' );
	update_option( 'woocommerce_specific_ship_to_countries', array( 'LK' ) );
	update_option( 'woocommerce_enable_reviews', 'yes' );
	update_option( 'woocommerce_review_rating_verification_required', 'yes' ); // genuine reviews only.

	// Payments: COD + bank transfer (placeholder bank details — replace before launch).
	$cod = get_option( 'woocommerce_cod_settings', array() );
	if ( empty( $cod['enabled'] ) ) {
		update_option(
			'woocommerce_cod_settings',
			array_merge(
				$cod,
				array(
					'enabled'      => 'yes',
					'title'        => 'Cash on Delivery',
					'description'  => 'Pay in cash when your costume is delivered (Sri Lanka only).',
					'instructions' => 'Please keep the exact amount ready. Our courier will confirm by phone.',
				)
			)
		);
	}
	$bacs = get_option( 'woocommerce_bacs_settings', array() );
	if ( empty( $bacs['enabled'] ) ) {
		update_option(
			'woocommerce_bacs_settings',
			array_merge(
				$bacs,
				array(
					'enabled'      => 'yes',
					'title'        => 'Bank Transfer',
					'description'  => 'Transfer to our bank account and share the slip on WhatsApp. PLACEHOLDER — update account details in WooCommerce → Settings → Payments.',
					'instructions' => "Bank: [Your bank]\nBranch: [Your branch]\nAccount name: [VASTRA]\nAccount number: [XXXX XXXX XXXX]\n\nSend your transfer slip via WhatsApp to confirm your order.",
					'accounts'     => array(
						array(
							'account_name'   => '[PLACEHOLDER — account name]',
							'account_number' => '[XXXX XXXX XXXX]',
							'bank_name'      => '[Your bank]',
							'sort_code'      => '[Branch code]',
							'iban'           => '',
							'bic'            => '',
						),
					),
				)
			)
		);
	}

	// Shipping: island-wide flat rate (placeholder fee; district overrides live in VASTRA Store settings).
	$zone = vastra_core_lk_zone();
	if ( $zone ) {
		$has_flat = false;
		foreach ( $zone->get_shipping_methods() as $method ) {
			if ( 'flat_rate' === $method->id ) {
				$has_flat = true;
			}
		}
		if ( ! $has_flat ) {
			$instance_id = $zone->add_shipping_method( 'flat_rate' );
			if ( $instance_id ) {
				update_option(
					'woocommerce_flat_rate_' . $instance_id . '_settings',
					array(
						'title'      => 'Island-wide Delivery',
						'tax_status' => 'none',
						'cost'       => vastra_core_option( 'vastra_default_fee' ),
					)
				);
			}
		}
	}
	$log[] = __( 'Currency (LKR), Sri Lanka checkout, COD + bank transfer, and flat-rate shipping configured (placeholders — verify before launch).', 'vastra-core' );

	// Hero image + placeholder WhatsApp number so buttons render immediately.
	$hero_id = vastra_core_import_image( 'hero.jpg' );
	if ( $hero_id && ! get_theme_mod( 'vastra_hero_image' ) ) {
		set_theme_mod( 'vastra_hero_image', $hero_id );
	}
	if ( ! vastra_core_option( 'vastra_whatsapp_number' ) ) {
		update_option( 'vastra_whatsapp_number', '94770000000' ); // PLACEHOLDER.
		set_theme_mod( 'vastra_whatsapp_number', '94770000000' );
		$log[] = __( 'A placeholder WhatsApp number (94770000000) was set so buttons render — replace it in VASTRA Store → Settings.', 'vastra-core' );
	}
	$log[] = __( 'Hero image set.', 'vastra-core' );

	return $log;
}

/**
 * Sri Lanka shipping zone (create or fetch).
 */
function vastra_core_lk_zone() {
	$zones = WC_Shipping_Zones::get_zones();
	foreach ( $zones as $zone_data ) {
		$zone = WC_Shipping_Zones::get_zone( $zone_data['id'] );
		foreach ( $zone->get_zone_locations() as $location ) {
			if ( 'country' === $location->type && 'LK' === $location->code ) {
				return $zone;
			}
		}
	}
	$zone = new WC_Shipping_Zone();
	$zone->set_zone_name( 'Sri Lanka' );
	$zone->add_location( 'LK', 'country' );
	$zone->save();
	return $zone;
}

/**
 * Create demo pages (placeholder policies) and return [ key => page_id ].
 */
function vastra_core_demo_pages() {
	$pages = array(
		'home'          => array(
			'title'   => 'Home',
			'slug'    => 'home',
			'content' => '',
		),
		'custom-orders' => array(
			'title'   => 'Custom Orders',
			'slug'    => 'custom-orders',
			'content' => '<h2>Made-to-measure dance costumes</h2>
<p>Tell us what you are performing, your colours, measurements and date — we will craft it for you. Fill in the form below, or message us on WhatsApp.</p>
[vastra_custom_order_form]',
		),
		'shipping'      => array(
			'title'   => 'Shipping & Delivery',
			'slug'    => 'shipping-delivery',
			'content' => vastra_core_policy_shipping(),
		),
		'returns'       => array(
			'title'   => 'Returns & Exchanges',
			'slug'    => 'returns-exchanges',
			'content' => vastra_core_policy_returns(),
		),
		'privacy'       => array(
			'title'   => 'Privacy Policy',
			'slug'    => 'privacy-policy',
			'content' => vastra_core_policy_privacy(),
		),
		'terms'         => array(
			'title'   => 'Terms & Conditions',
			'slug'    => 'terms-conditions',
			'content' => vastra_core_policy_terms(),
		),
	);

	$ids = array();
	foreach ( $pages as $key => $page ) {
		$existing = get_page_by_path( $page['slug'] );
		if ( $existing ) {
			$ids[ $key ] = $existing->ID;
			continue;
		}
		$ids[ $key ] = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => $page['title'],
				'post_name'    => $page['slug'],
				'post_content' => $page['content'],
			)
		);
	}
	return $ids;
}

/**
 * Build primary + footer menus and assign theme locations.
 */
function vastra_core_demo_menus( $pages ) {
	// Primary menu.
	$primary_id = wp_create_nav_menu( 'VASTRA Main' );
	$shop_link  = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );

	wp_update_nav_menu_item( $primary_id, 0, array( 'menu-item-title' => 'Home', 'menu-item-url' => home_url( '/' ), 'menu-item-status' => 'publish' ) );
	wp_update_nav_menu_item( $primary_id, 0, array( 'menu-item-title' => 'Shop', 'menu-item-url' => $shop_link, 'menu-item-status' => 'publish' ) );

	// Category dropdown under Shop.
	$shop_item_id = 0;
	$items = wp_get_nav_menu_items( $primary_id );
	foreach ( (array) $items as $item ) {
		if ( 'Shop' === $item->title ) {
			$shop_item_id = $item->ID;
		}
	}
	if ( $shop_item_id ) {
		$cats = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'number' => 8 ) );
		if ( ! is_wp_error( $cats ) ) {
			foreach ( $cats as $cat ) {
				wp_update_nav_menu_item(
					$primary_id,
					0,
					array(
						'menu-item-title'     => $cat->name,
						'menu-item-url'       => get_term_link( $cat ),
						'menu-item-status'    => 'publish',
						'menu-item-parent-id' => $shop_item_id,
					)
				);
			}
		}
	}
	wp_update_nav_menu_item( $primary_id, 0, array( 'menu-item-title' => 'Custom Orders', 'menu-item-url' => get_permalink( $pages['custom-orders'] ), 'menu-item-status' => 'publish' ) );
	wp_update_nav_menu_item( $primary_id, 0, array( 'menu-item-title' => 'Delivery Info', 'menu-item-url' => get_permalink( $pages['shipping'] ), 'menu-item-status' => 'publish' ) );

	// Footer menu.
	$footer_id = wp_create_nav_menu( 'VASTRA Footer' );
	foreach ( array( 'custom-orders' => 'Custom Orders', 'shipping' => 'Shipping & Delivery', 'returns' => 'Returns & Exchanges', 'privacy' => 'Privacy Policy', 'terms' => 'Terms & Conditions' ) as $key => $label ) {
		wp_update_nav_menu_item( $footer_id, 0, array( 'menu-item-title' => $label, 'menu-item-url' => get_permalink( $pages[ $key ] ), 'menu-item-status' => 'publish' ) );
	}

	set_theme_mod(
		'nav_menu_locations',
		array_merge(
			(array) get_theme_mod( 'nav_menu_locations', array() ),
			array(
				'primary' => $primary_id,
				'footer'  => $footer_id,
			)
		)
	);
}

function vastra_core_policy_shipping() {
	return '<p><em>[Placeholder — replace with your actual shipping policy before launch.]</em></p>
<h2>Delivery coverage</h2>
<p>We deliver to all districts of Sri Lanka. Orders are dispatched from our studio once payment is confirmed (bank transfer) or the order is confirmed by phone (Cash on Delivery).</p>
<h2>Delivery times</h2>
<ul><li>Ready-made costumes: dispatched within 2–4 working days.</li><li>Custom-made costumes: timeline confirmed individually after measurements are finalised.</li></ul>
<h2>Delivery fees</h2>
<p>Delivery fees are calculated at checkout and may vary by district. The fee is shown before you confirm your order.</p>
<h2>Receiving your order</h2>
<p>Please inspect your costume on delivery and report any issue within 24 hours with photos via WhatsApp.</p>';
}

function vastra_core_policy_returns() {
	return '<p><em>[Placeholder — replace with your actual returns policy before launch.]</em></p>
<h2>Ready-made costumes</h2>
<p>Unused ready-made costumes in original condition may be exchanged for size within 7 days of delivery, subject to stock.</p>
<h2>Custom-made costumes</h2>
<p>Custom-made costumes are crafted to your measurements and cannot be returned or refunded. We confirm all measurements with you before production begins.</p>
<h2>Damaged or incorrect items</h2>
<p>Contact us within 24 hours of delivery with photos. We will repair, replace or refund at our discretion.</p>
<h2>How to request</h2>
<p>Message us on WhatsApp with your order number and photos of the item.</p>';
}

function vastra_core_policy_privacy() {
	return '<p><em>[Placeholder — have your privacy policy reviewed for your business before launch.]</em></p>
<h2>What we collect</h2>
<p>Your name, phone number, delivery address, district, order details and (for custom orders) measurements and reference images — used only to fulfil your order.</p>
<h2>How we use it</h2>
<p>To process orders, arrange delivery, and contact you about your order. We do not sell your data.</p>
<h2>WhatsApp</h2>
<p>When you order via WhatsApp, your message is handled under WhatsApp’s own privacy policy in addition to ours.</p>
<h2>Contact</h2>
<p>Questions about your data: [your contact email].</p>';
}

function vastra_core_policy_terms() {
	return '<p><em>[Placeholder — have your terms reviewed for your business before launch.]</em></p>
<h2>Orders</h2>
<p>Orders are confirmed by phone or WhatsApp. Prices are in Sri Lankan Rupees (LKR) and may change without notice; the price at order confirmation applies.</p>
<h2>Payment</h2>
<p>We accept Cash on Delivery and bank transfer where available. Bank transfer orders are produced after payment confirmation.</p>
<h2>Custom orders</h2>
<p>Custom orders require a deposit and confirmed measurements. Production time is agreed per order.</p>
<h2>Liability</h2>
<p>Colours may vary slightly from photos due to screen settings and dye lots.</p>';
}
