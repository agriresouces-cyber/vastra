<?php
/**
 * VASTRA Core — Sri Lanka checkout: districts, delivery fees, field tuning.
 *
 * @package VASTRA_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sell and ship to Sri Lanka only.
 */
add_filter( 'woocommerce_countries_allowed_countries', 'vastra_core_lk_only' );
add_filter( 'woocommerce_countries_shipping_countries', 'vastra_core_lk_only' );
function vastra_core_lk_only( $countries ) {
	return array( 'LK' => __( 'Sri Lanka', 'vastra-core' ) );
}

add_filter(
	'woocommerce_default_address_fields',
	function ( $fields ) {
		if ( isset( $fields['country'] ) ) {
			$fields['country']['default'] = 'LK';
		}
		if ( isset( $fields['company'] ) ) {
			$fields['company']['class'] = array( 'form-row-wide', 'hidden' );
			$fields['company']['required'] = false;
		}
		if ( isset( $fields['address_1'] ) ) {
			$fields['address_1']['label'] = __( 'Street address', 'vastra-core' );
			$fields['address_1']['placeholder'] = __( 'House number and street name', 'vastra-core' );
		}
		if ( isset( $fields['city'] ) ) {
			$fields['city']['label'] = __( 'Town / City', 'vastra-core' );
		}
		if ( isset( $fields['postcode'] ) ) {
			$fields['postcode']['required'] = false;
		}
		return $fields;
	}
);

/**
 * Checkout fields: require phone, add District dropdown, friendly notes label.
 */
add_filter(
	'woocommerce_checkout_fields',
	function ( $fields ) {
		$districts = function_exists( 'vastra_sri_lankan_districts' )
			? vastra_sri_lankan_districts()
			: array( 'Colombo', 'Gampaha', 'Kalutara', 'Kandy', 'Matale', 'Nuwara Eliya', 'Galle', 'Matara', 'Hambantota', 'Jaffna', 'Kilinochchi', 'Mannar', 'Vavuniya', 'Mullaitivu', 'Batticaloa', 'Ampara', 'Trincomalee', 'Kurunegala', 'Puttalam', 'Anuradhapura', 'Polonnaruwa', 'Badulla', 'Monaragala', 'Ratnapura', 'Kegalle' );

		$district_field = array(
			'type'        => 'select',
			'label'       => __( 'District', 'vastra-core' ),
			'required'    => true,
			'class'       => array( 'form-row-wide' ),
			'options'     => array( '' => __( 'Select your district', 'vastra-core' ) ) + array_combine( $districts, $districts ),
			'priority'    => 65,
		);

		$fields['billing']['billing_district'] = $district_field;
		$fields['shipping']['shipping_district'] = $district_field;

		$fields['billing']['billing_phone']['required'] = true;
		$fields['billing']['billing_phone']['label'] = __( 'Phone (WhatsApp preferred)', 'vastra-core' );
		$fields['billing']['billing_email']['required'] = false;
		$fields['billing']['billing_email']['class'] = array( 'form-row-wide' );

		// Ship to the same address by default (single-address flow).
		$fields['shipping']['shipping_address_1']['placeholder'] = __( 'Delivery address — house number and street', 'vastra-core' );

		if ( isset( $fields['order']['order_comments'] ) ) {
			$fields['order']['order_comments']['label'] = __( 'Order notes', 'vastra-core' );
			$fields['order']['order_comments']['placeholder'] = __( 'Delivery instructions, performance date, colour preferences…', 'vastra-core' );
		}
		return $fields;
	}
);

/**
 * Keep district in admin order view, emails and order meta.
 */
add_filter(
	'woocommerce_order_get_formatted_billing_address',
	function ( $address, $order ) {
		$district = $order->get_meta( '_billing_district' );
		if ( $district ) {
			$address['district'] = $district;
		}
		return $address;
	},
	10,
	2
);
add_filter(
	'woocommerce_order_get_formatted_shipping_address',
	function ( $address, $order ) {
		$district = $order->get_meta( '_shipping_district' );
		if ( $district ) {
			$address['district'] = $district;
		}
		return $address;
	},
	10,
	2
);
add_filter(
	'woocommerce_localisation_address_formats',
	function ( $formats ) {
		$formats['LK'] = "{name}\n{company}\n{address_1}\n{address_2}\n{city}\n{district}\n{postcode}\n{country}";
		return $formats;
	}
);
add_filter(
	'woocommerce_formatted_address_replacements',
	function ( $replacements, $args ) {
		$replacements['{district}'] = isset( $args['district'] ) ? $args['district'] : '';
		return $replacements;
	},
	10,
	2
);

/**
 * District-based delivery fee adjustment on the flat rate.
 */
add_filter(
	'woocommerce_package_rates',
	function ( $rates ) {
		if ( vastra_core_option( 'vastra_enable_district_fees' ) !== '1' ) {
			return $rates;
		}
		$district = '';
		if ( WC()->customer ) {
			$district = WC()->customer->get_meta( 'billing_district' );
			if ( ! $district ) {
				$district = WC()->customer->get_billing_city(); // graceful fallback.
			}
		}
		// Posted checkout data takes priority (district chosen on the form).
		$post = WC()->checkout() ? WC()->checkout()->get_posted_data() : array();
		if ( ! empty( $post['billing_district'] ) ) {
			$district = $post['billing_district'];
		} elseif ( ! empty( $post['shipping_district'] ) ) {
			$district = $post['shipping_district'];
		}
		if ( ! $district ) {
			return $rates;
		}
		$map = vastra_core_district_fee_map();
		$key = mb_strtolower( trim( $district ) );
		if ( ! isset( $map[ $key ] ) ) {
			return $rates; // No district override — keep zone/default rate.
		}
		foreach ( $rates as $rate ) {
			if ( 'flat_rate' === $rate->get_method_id() ) {
				$rate->set_cost( $map[ $key ] );
			}
		}
		return $rates;
	},
	20
);
