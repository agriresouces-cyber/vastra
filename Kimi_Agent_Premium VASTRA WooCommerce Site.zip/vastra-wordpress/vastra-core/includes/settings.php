<?php
/**
 * VASTRA Core — admin settings (store WhatsApp number, toggles, delivery fees).
 *
 * @package VASTRA_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the VASTRA Store admin menu.
 */
function vastra_core_admin_menu() {
	add_menu_page(
		__( 'VASTRA Store', 'vastra-core' ),
		__( 'VASTRA Store', 'vastra-core' ),
		'manage_options',
		'vastra-store',
		'vastra_core_settings_page',
		'dashicons-store',
		56
	);
	add_submenu_page(
		'vastra-store',
		__( 'Settings', 'vastra-core' ),
		__( 'Settings', 'vastra-core' ),
		'manage_options',
		'vastra-store',
		'vastra_core_settings_page'
	);
}
add_action( 'admin_menu', 'vastra_core_admin_menu' );

/**
 * Register settings.
 */
function vastra_core_register_settings() {
	register_setting(
		'vastra_store_settings',
		'vastra_whatsapp_number',
		array(
			'sanitize_callback' => function ( $v ) {
				return preg_replace( '/\D+/', '', (string) $v );
			},
		)
	);
	register_setting( 'vastra_store_settings', 'vastra_floating_whatsapp', array( 'sanitize_callback' => 'sanitize_text_field' ) );
	register_setting( 'vastra_store_settings', 'vastra_whatsapp_product', array( 'sanitize_callback' => 'sanitize_text_field' ) );
	register_setting(
		'vastra_store_settings',
		'vastra_default_fee',
		array(
			'sanitize_callback' => function ( $v ) {
				return (string) max( 0, (float) $v );
			},
		)
	);
	register_setting( 'vastra_store_settings', 'vastra_enable_district_fees', array( 'sanitize_callback' => 'sanitize_text_field' ) );
	register_setting(
		'vastra_store_settings',
		'vastra_district_fees',
		array(
			'sanitize_callback' => 'vastra_core_sanitize_district_fees',
		)
	);
}
add_action( 'admin_init', 'vastra_core_register_settings' );

/**
 * Sanitize "District:fee" lines.
 */
function vastra_core_sanitize_district_fees( $value ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $value ) as $line ) {
		$line = trim( $line );
		if ( ! $line || false === strpos( $line, ':' ) ) {
			continue;
		}
		list( $district, $fee ) = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( $district && is_numeric( $fee ) ) {
			$out[] = $district . ':' . (float) $fee;
		}
	}
	return implode( "\n", $out );
}

/**
 * Parse district fee map into [ district => fee ].
 */
function vastra_core_district_fee_map() {
	$map = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) vastra_core_option( 'vastra_district_fees' ) ) as $line ) {
		if ( false === strpos( $line, ':' ) ) {
			continue;
		}
		list( $district, $fee ) = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( $district ) {
			$map[ mb_strtolower( $district ) ] = (float) $fee;
		}
	}
	return $map;
}

/**
 * Settings page HTML.
 */
function vastra_core_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'VASTRA Store Settings', 'vastra-core' ); ?></h1>
		<p class="description">
			<?php esc_html_e( 'Everything marked PLACEHOLDER must be replaced with your real business details before launch.', 'vastra-core' ); ?>
		</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'vastra_store_settings' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="vastra_whatsapp_number"><?php esc_html_e( 'Store WhatsApp number', 'vastra-core' ); ?></label></th>
					<td>
						<input name="vastra_whatsapp_number" id="vastra_whatsapp_number" type="text" class="regular-text"
							value="<?php echo esc_attr( vastra_core_option( 'vastra_whatsapp_number' ) ); ?>" placeholder="9477XXXXXXX">
						<p class="description"><?php esc_html_e( 'International format, digits only (Sri Lanka: 94 + number without the leading 0). Powers every "Order on WhatsApp" button. PLACEHOLDER until set.', 'vastra-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'WhatsApp on product pages', 'vastra-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="vastra_whatsapp_product" value="1" <?php checked( vastra_core_option( 'vastra_whatsapp_product' ), '1' ); ?>>
						<?php esc_html_e( 'Show the "Order on WhatsApp" button on every product page (pre-fills product name, code, size, colour, quantity and link).', 'vastra-core' ); ?></label>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Floating WhatsApp button', 'vastra-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="vastra_floating_whatsapp" value="1" <?php checked( vastra_core_option( 'vastra_floating_whatsapp' ), '1' ); ?>>
						<?php esc_html_e( 'Show the floating WhatsApp chat button site-wide.', 'vastra-core' ); ?></label>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="vastra_default_fee"><?php esc_html_e( 'Default delivery fee (LKR)', 'vastra-core' ); ?></label></th>
					<td>
						<input name="vastra_default_fee" id="vastra_default_fee" type="number" min="0" step="1" class="small-text"
							value="<?php echo esc_attr( vastra_core_option( 'vastra_default_fee' ) ); ?>">
						<p class="description"><?php esc_html_e( 'PLACEHOLDER flat fee applied when a district has no specific fee. For full control use WooCommerce → Settings → Shipping zones instead.', 'vastra-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'District delivery fees', 'vastra-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="vastra_enable_district_fees" value="1" <?php checked( vastra_core_option( 'vastra_enable_district_fees' ), '1' ); ?>>
						<?php esc_html_e( 'Adjust the flat-rate delivery fee by the customer\'s district.', 'vastra-core' ); ?></label>
						<p>
							<textarea name="vastra_district_fees" rows="8" class="large-text code" placeholder="Colombo:350&#10;Gampaha:400&#10;Kandy:450&#10;Jaffna:900"><?php echo esc_textarea( vastra_core_option( 'vastra_district_fees' ) ); ?></textarea>
						</p>
						<p class="description"><?php esc_html_e( 'One per line, "District:fee" in LKR. District names must match the checkout dropdown. PLACEHOLDER examples shown.', 'vastra-core' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>

		<hr>
		<h2><?php esc_html_e( 'Payments', 'vastra-core' ); ?></h2>
		<p><?php esc_html_e( 'Cash on Delivery and Bank Transfer are standard WooCommerce gateways. Configure them under', 'vastra-core' ); ?>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout' ) ); ?>"><?php esc_html_e( 'WooCommerce → Settings → Payments', 'vastra-core' ); ?></a>.
			<?php esc_html_e( 'The demo importer enables both with PLACEHOLDER bank details — replace them with your real account before accepting orders.', 'vastra-core' ); ?>
		</p>
	</div>
	<?php
}
