<?php
/**
 * VASTRA Core — WhatsApp ordering on product pages.
 *
 * @package VASTRA_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Render the "Order on WhatsApp" button below the add-to-cart form.
 */
function vastra_core_product_whatsapp_button() {
	if ( vastra_core_option( 'vastra_whatsapp_product' ) !== '1' ) {
		return;
	}
	$number = vastra_core_option( 'vastra_whatsapp_number' );
	if ( ! $number ) {
		return; // No number configured yet — render nothing rather than a dead button.
	}

	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}

	$message = sprintf(
		/* translators: 1: product name, 2: product SKU. */
		__( 'Hello VASTRA! I would like to order: %1$s (Code: %2$s)', 'vastra-core' ),
		$product->get_name(),
		$product->get_sku() ? $product->get_sku() : $product->get_id()
	);
	$base_url = 'https://wa.me/' . $number . '?text=' . rawurlencode( $message );

	// Attribute labels so the JS can read the shopper's chosen size/colour.
	$attributes = array();
	foreach ( $product->get_attributes() as $attr ) {
		if ( $attr->is_taxonomy() ) {
			$attributes[ 'attribute_' . $attr->get_name() ] = wc_attribute_label( $attr->get_name() );
		} else {
			$attributes[ 'attribute_' . sanitize_title( $attr->get_name() ) ] = $attr->get_name();
		}
	}
	?>
	<div class="vastra-wa-wrap">
		<a class="vastra-wa-order" href="<?php echo esc_url( $base_url ); ?>" target="_blank" rel="noopener noreferrer"
			data-vastra-wa
			data-number="<?php echo esc_attr( $number ); ?>"
			data-name="<?php echo esc_attr( $product->get_name() ); ?>"
			data-sku="<?php echo esc_attr( $product->get_sku() ? $product->get_sku() : $product->get_id() ); ?>"
			data-url="<?php echo esc_attr( get_permalink( $product->get_id() ) ); ?>"
			data-attributes="<?php echo esc_attr( wp_json_encode( $attributes ) ); ?>">
			<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38c1.45.79 3.08 1.21 4.79 1.21 5.46 0 9.91-4.45 9.91-9.91C21.95 6.45 17.5 2 12.04 2zm0 18.03c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a7.9 7.9 0 0 1-1.26-4.26c0-4.37 3.56-7.93 7.94-7.93 4.38 0 7.93 3.56 7.93 7.93 0 4.37-3.55 7.93-7.62 7.93zm4.34-5.94c-.24-.12-1.41-.7-1.63-.78-.22-.08-.38-.12-.54.12-.16.24-.62.78-.76.94-.14.16-.28.18-.52.06-.24-.12-1.01-.37-1.92-1.18-.71-.63-1.19-1.41-1.33-1.65-.14-.24-.01-.37.11-.49.11-.11.24-.28.36-.42.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.54-1.3-.74-1.78-.19-.47-.39-.4-.54-.41h-.46c-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2s.86 2.32.98 2.48c.12.16 1.69 2.58 4.09 3.62.57.25 1.02.39 1.37.5.57.18 1.1.16 1.51.1.46-.07 1.41-.58 1.61-1.14.2-.56.2-1.04.14-1.14-.06-.1-.22-.16-.46-.28z"/></svg>
			<?php esc_html_e( 'Order on WhatsApp', 'vastra-core' ); ?>
		</a>
		<p class="vastra-wa-note"><?php esc_html_e( 'Your selected size, colour and quantity are included in the message automatically.', 'vastra-core' ); ?></p>
	</div>
	<?php
}
add_action( 'woocommerce_after_add_to_cart_form', 'vastra_core_product_whatsapp_button' );

/**
 * Front-end script that rebuilds the wa.me link on click with the live selection.
 */
function vastra_core_whatsapp_assets() {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	if ( vastra_core_option( 'vastra_whatsapp_product' ) !== '1' ) {
		return;
	}
	wp_enqueue_script( 'vastra-whatsapp', VASTRA_CORE_URL . 'assets/js/whatsapp.js', array(), VASTRA_CORE_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'vastra_core_whatsapp_assets' );
