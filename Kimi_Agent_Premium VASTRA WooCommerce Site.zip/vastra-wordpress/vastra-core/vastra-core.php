<?php
/**
 * Plugin Name:       VASTRA Core
 * Plugin URI:        https://example.com/vastra
 * Description:       Store engine for the VASTRA theme: WhatsApp ordering, Sri Lanka checkout (districts + delivery fees), custom costume enquiry form, and one-click demo content. Requires WooCommerce.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * Author:            VASTRA
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       vastra-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'VASTRA_CORE_VERSION', '1.0.0' );
define( 'VASTRA_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'VASTRA_CORE_URL', plugin_dir_url( __FILE__ ) );

require_once VASTRA_CORE_DIR . 'includes/settings.php';
require_once VASTRA_CORE_DIR . 'includes/whatsapp.php';
require_once VASTRA_CORE_DIR . 'includes/checkout.php';
require_once VASTRA_CORE_DIR . 'includes/enquiry.php';
require_once VASTRA_CORE_DIR . 'includes/demo-importer.php';

/**
 * Shared option getter with sensible defaults.
 */
function vastra_core_option( $key, $default = '' ) {
	$defaults = array(
		'vastra_whatsapp_number'    => '',
		'vastra_floating_whatsapp'  => '1',
		'vastra_whatsapp_product'   => '1',
		'vastra_default_fee'        => '450',
		'vastra_district_fees'      => '',
		'vastra_enable_district_fees' => '1',
	);
	if ( isset( $defaults[ $key ] ) && false === get_option( $key, false ) ) {
		return $defaults[ $key ];
	}
	return get_option( $key, $default );
}
