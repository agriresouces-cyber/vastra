# VASTRA — WordPress + WooCommerce Store

A complete, installable e-commerce package for **VASTRA**, a Sri Lankan dance costume business selling island-wide. Deep maroon, black, warm ivory and gold; elegant typography; mobile-first; WhatsApp ordering alongside a real WooCommerce checkout.

## What's in this package

| File | What it is |
|---|---|
| `vastra.zip` | The **VASTRA WordPress theme** (design, homepage, templates, SEO basics) |
| `vastra-core.zip` | The **VASTRA Core plugin** (WhatsApp ordering, Sri Lanka checkout, custom enquiry form, one-click demo content, product photos) |

You install **both**. The theme works alone, but WhatsApp buttons, the enquiry form and demo products come from the plugin.

---

## Requirements

- A self-hosted WordPress site (WordPress 6.0+, PHP 7.4+ — PHP 8.1+ recommended)
- WooCommerce 8.0+ (free, from the WordPress plugin directory)
- HTTPS enabled on your hosting (free via Let's Encrypt on most hosts)
- A WhatsApp number for the store (e.g. a WhatsApp Business line)

---

## Install (15 minutes)

1. **Install WordPress + WooCommerce** on your hosting. Run the WooCommerce setup wizard (currency and country will be set by the demo importer anyway).
2. **Install the theme:** Appearance → Themes → Add New → Upload Theme → choose `vastra.zip` → Install → **Activate**.
3. **Install the plugin:** Plugins → Add New → Upload Plugin → choose `vastra-core.zip` → Install → **Activate**.
4. **Import demo content:** WP Admin → **VASTRA Store → Demo Content** → "Install / refresh demo content".
   This creates: 8 categories, 15 editable demo products (LKR prices, SKUs, stock, size/colour variations), the homepage, menus, policy pages (placeholders), Cash on Delivery + Bank Transfer (placeholders), island-wide flat-rate shipping, and the hero image.
5. **Set your WhatsApp number:** VASTRA Store → Settings → "Store WhatsApp number" — international format, digits only (Sri Lanka: `94` + number without the leading 0, e.g. `9477XXXXXXX`).
6. **Set your logo:** Appearance → Customize → Site Identity → Logo. (Placeholder: the word-mark "VASTRA." displays until you upload one.)
7. **Flush permalinks once:** Settings → Permalinks → Save Changes (no changes needed — this refreshes product/category URLs).
8. Done — visit your homepage.

---

## Replacing every placeholder before launch

Everything below is a deliberate placeholder. Search-and-replace in one pass:

| Placeholder | Where to change it |
|---|---|
| WhatsApp number `94770000000` | VASTRA Store → Settings |
| Phone `+94 XX XXX XXXX`, email, studio address | Appearance → Customize → VASTRA Store → Contact & WhatsApp |
| Bank account details | WooCommerce → Settings → Payments → Bank Transfer → Manage |
| Delivery fees (default 450 LKR + district table) | VASTRA Store → Settings, and/or WooCommerce → Settings → Shipping |
| Social links | Appearance → Customize → VASTRA Store → Social Links |
| Policy text (Shipping, Returns, Privacy, Terms) | Pages → each page is clearly marked `[Placeholder — …]` |
| Demo products & AI photos | Products → All Products (edit/replace freely; nothing is locked) |
| Meta description | Appearance → Customize → VASTRA Store → Delivery Information |

---

## How the two ordering paths work

They are **separate by design** — a customer picks one:

1. **Online checkout (WooCommerce):** product → variation (size/colour) → cart → checkout (name, phone, Sri Lankan address, **district dropdown**, order notes) → delivery fee → **Cash on Delivery** or **Bank Transfer** → order confirmation email + order appears in WooCommerce → Orders with stock reduced automatically.
2. **Order on WhatsApp:** every product page has a green button that opens WhatsApp with a pre-filled message containing **product name, code (SKU), selected size, selected colour, quantity, and the product URL**. The number is configurable in one place (VASTRA Store → Settings). A floating WhatsApp chat button (also toggleable) appears site-wide.

## Custom costume enquiries

The **Custom Orders** page (`[vastra_custom_order_form]` shortcode) collects: name, phone, email, costume type, preferred colours, quantity, required-by date, measurements, design notes, and **up to 3 reference images** (JPG/PNG/WebP, 5 MB max). Submissions are saved under **VASTRA Store → Custom Enquiries** and emailed to the site admin, with a WhatsApp hand-off link shown to the customer after submitting. Spam protection: nonce + honeypot + file-type validation.

## Delivery fees by district

Checkout is locked to Sri Lanka and asks for the customer's **district** (all 25 districts). Two ways to price delivery:

- **Simple:** VASTRA Store → Settings → default fee + optional `District:fee` overrides (one per line, e.g. `Colombo:350`). This adjusts the flat-rate method automatically.
- **Advanced:** WooCommerce → Settings → Shipping → Zones for full control.

## Honest-content guarantees

- **No fabricated reviews.** The homepage review section renders *only real, approved WooCommerce reviews*; with none, it shows an honest empty state. Product ratings come from verified buyers only (`woocommerce_review_rating_verification_required` is enabled by the importer).
- **No fabricated credentials.** All contact details, bank accounts and policies are clearly marked placeholders.
- **Demo products are fully editable** and clearly labelled as demo in their descriptions.

## Photography

All 16 images are AI-generated demo photography (no real people depicted; no third-party photos, so no licensing issues). Categories without a suitable generation use costume detail crops (face-free). Replace them with your own costume photography at any time — product images are standard WooCommerce featured images. Regenerating at higher quality is recommended before launch.

## SEO, speed & HTTPS

- **Built in:** title tags, meta description (customizable), Open Graph tags, ClothingStore schema.org JSON-LD, semantic HTML, lazy-loaded images with `srcset` sizes, preconnected Google Fonts with `display=swap`, deferred JS, no icon fonts (inline SVG), no jQuery on the front end.
- **Recommended plugins (optional):** an SEO plugin (Rank Math or Yoast) for sitemaps/breadcrumbs, a caching plugin (WP Super Cache or your host's cache), and an image-optimization plugin. WooCommerce image sizes are already tuned to the theme (`vastra-card`, `vastra-hero`).
- **HTTPS:** enable your host's free SSL, then set both URLs under Settings → General to `https://`. If your host can't force redirects, the "Really Simple SSL" plugin does it in one click.

## Going live checklist

1. Replace every placeholder (table above).
2. Delete or edit demo products; add real stock quantities.
3. Test one full order with Cash on Delivery and one with Bank Transfer (then refund/cancel).
4. Test the WhatsApp button on a variable product — confirm size/colour/qty appear in the message.
5. Submit a test custom enquiry with a reference image.
6. Check the site on a real phone (375px width) — the design is mobile-first.
7. Publish privacy/terms after your own review.

---

*VASTRA theme + VASTRA Core v1.0.0. GPL v2 or later. Fonts: Playfair Display & Jost (Google Fonts, OFL).*
